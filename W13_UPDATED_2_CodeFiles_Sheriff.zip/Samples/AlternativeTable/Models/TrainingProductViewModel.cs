﻿using System.Collections.Generic;

namespace AlternativeTable
{
  public class TrainingProductViewModel : AppViewModelBase
  {
    public List<TrainingProduct> Products { get; set; } = new List<TrainingProduct>();

    public void LoadProducts() {
      TrainingProductManager mgr = new TrainingProductManager();

      Products = mgr.Get();
    }
  }
}
