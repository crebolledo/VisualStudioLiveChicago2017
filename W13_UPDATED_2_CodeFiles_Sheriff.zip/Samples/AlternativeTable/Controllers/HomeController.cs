﻿using System.Web.Mvc;

namespace AlternativeTable.Controllers
{
  public class HomeController : AppControllerBase
  {
    public ActionResult Index() {
      return View();
    }
  }
}