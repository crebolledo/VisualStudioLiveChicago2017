﻿Alternative Table Sample Project
--------------------------------
The samples in this project illustrate different ways to express tables so they display better on a mobile device such as a SmartPhone.
All samples use Bootstrap for styling and responsive UI.


Table Samples (\Views\Tables folder)
---------------------------------------------------------------------------------
Sample01 - A HTML table using a product name as hyperlink, and a "delete" button.
Sample01a - Remove table-responsive (text is wrapped)
Sample02 - Reduce table to 2 columns. Product data in the first column. The second column has the delete button.
Sample03 - A HTML table using a "edit" and a "delete" button.
Sample04 - Reduce table to 2 columns. Product data in the first column. The second column has the actions.
Sample05 - Reduce table to 2 columns. Product data in the first column. Different styling for the Product name, and the name is a hyperlink. The second column contains just the "delete" button.
Sample06 - Use Chris Coyier's reponsive data tables (https://css-tricks.com/responsive-data-tables/)


Alternative to Table Samples (\Views\TablesAlternatives folder)
---------------------------------------------------------------------------------
Sample01 - Use Bootstrap panel control. The title contains the product name, the body contains the product data, and the footer contains the actions to perform.
Sample02 - Use Boostrap 'list-group'. Two bootstrap columns are used to separate "label" and "data".
Sample03 - Use a blockquote to display the product name.
Sample04 - Move the actions to the right of the product.
Sample05 - Display the product name in a label with additional styling.
Sample06 - Product name is now a hyperlink to edit, and the edit button is removed.
Sample07 - Add a drop-shadow and a background behind the product list.
Sample08 - Use a Bootstrap Carousel


Collapsing Tables Samples (\Views\TablesCollapse folder)
---------------------------------------------------------------------------------
Sample01 - Use Bootstrap panel control, but no footer. Everything is collapsed by default.
Sample02 - Use Boostrap 'list-group'. Everything is collapsed by default.


Detect Mobile (\Views\Product folder)
---------------------------------------------------------------------------------
_ProductList - For normal size browsers
_ProductList_Mobile - For mobile browsers
Product - Determines which of the above partial views to display



Other Resources
-----------------------------------------------------------------
Google search - "alternative to html table"

Browser Detection
https://51degrees.com
https://developer.mozilla.org/en-US/docs/Web/HTTP/Browser_detection_using_the_user_agent
http://www.useragentstring.com/pages/useragentstring.php?typ=Mobile%20Browser

Flex boxes
https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Flexible_Box_Layout/Using_CSS_flexible_boxes

Cards
https://material.io/guidelines/components/cards.html#cards-usage

Responsive Data Tables
https://css-tricks.com/responsive-data-tables/
https://css-tricks.com/responsive-data-table-roundup/
https://gist.github.com/hkirsman/3002480