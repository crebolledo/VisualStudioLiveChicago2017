﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class AddressController : AppController
  {
    public ActionResult Address()
    {
      AddressViewModel vm = new AddressViewModel();

      // Load collections
      LoadViewModelCollections(vm);

      return View(vm);
    }
     
    [HttpPost]
    public ActionResult Address(AddressViewModel vm)
    {
      // Validate the model
      bool ret = vm.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(vm.Entity);
      }

      // Load Collections
      LoadViewModelCollections(vm);

      return View(vm);
    }

    [HttpGet]
    public ActionResult ChangeCountryCode(string countryCode)
    {
      AddressViewModel vm = new AddressViewModel();

      // Load collections
      LoadViewModelCollections(vm);

      if (!string.IsNullOrEmpty(countryCode)) {
        vm.SetAddressTypeEnum(countryCode);
      }

      return PartialView("_Address", vm);
    }

    private void LoadViewModelCollections(AddressViewModel vm)
    {
      vm.LoadCountries(Server.MapPath("~/Xml/Countries.xml"));
      vm.LoadProvinces(Server.MapPath("~/Xml/CanadianProvinces.xml"));
      vm.LoadStates(Server.MapPath("~/Xml/USStates.xml"));
    }
  }
}