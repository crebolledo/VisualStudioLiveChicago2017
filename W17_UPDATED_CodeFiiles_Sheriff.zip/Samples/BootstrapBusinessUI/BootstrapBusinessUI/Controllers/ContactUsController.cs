﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class ContactUsController : AppController
  {
    public ActionResult ContactUs1()
    {
      ContactUs model = new ContactUs();

      model.Url = "http://";

      return View(model);
    }

    [HttpPost]
    public ActionResult ContactUs1(ContactUs model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }

    public ActionResult ContactUs2()
    {
      ContactUs model = new ContactUs();

      return View(model);
    }

    [HttpPost]
    public ActionResult ContactUs2(ContactUs model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }
    
    public ActionResult ContactUs3()
    {
      ContactUs model = new ContactUs();

      return View(model);
    }

    [HttpPost]
    public ActionResult ContactUs3(ContactUs model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }
  }
}