﻿using System.Web.Mvc;
using System.Collections.Generic;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class CreditCardController : AppController
  {
    public ActionResult CreditCard1()
    {
      CreditCardViewModel vm = new CreditCardViewModel();

      LoadViewModelCollections(vm);

      return View(vm);
    }

    [HttpPost]
    public ActionResult CreditCard1(CreditCardViewModel vm)
    {
      // Validate the model
      bool ret = vm.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(vm.Entity);
      }

      // Load view model collections
      LoadViewModelCollections(vm);

      return View(vm);
    }

    public ActionResult CreditCard2()
    {
      CreditCardViewModel vm = new CreditCardViewModel();

      LoadViewModelCollections(vm);

      return View(vm);
    }

    [HttpPost]
    public ActionResult CreditCard2(CreditCardViewModel vm)
    {
      // Validate the model
      bool ret = vm.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(vm.Entity);
      }

      // Load view model collections
      LoadViewModelCollections(vm);

      return View(vm);
    }
    
    private void LoadViewModelCollections(CreditCardViewModel vm)
    {
      vm.LoadCreditCardTypes(Server.MapPath("~/Xml/CreditCardTypes.xml"));
    }
  }
}