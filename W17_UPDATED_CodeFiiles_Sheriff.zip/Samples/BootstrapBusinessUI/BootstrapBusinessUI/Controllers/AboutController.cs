﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BootstrapBusinessUI.Controllers
{
  public class AboutController : Controller
  {
    public ActionResult About1()
    {
      return View();
    }

    public ActionResult About2()
    {
      return View();
    }

    public ActionResult About3()
    {
      return View();
    }    
  }
}