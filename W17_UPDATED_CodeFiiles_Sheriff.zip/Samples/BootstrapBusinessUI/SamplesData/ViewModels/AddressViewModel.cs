using System.Collections.Generic;

namespace SamplesData
{
  public class AddressViewModel : PDSAViewModelBase
  {
    #region Init Method
    public override void Init()
    {
      base.Init();

      Entity = new Address();

      // Initialize to US
      SetDisplay(Address.AddressTypeEnum.US);
    }
    #endregion

    #region Public Properties
    public List<USState> States { get; set; }
    public List<Country> Countries { get; set; }
    public List<CanadianProvince> Provinces { get; set; }
    public Address Entity { get; set; }
    public bool IsAddress3Visible { get; set; }
    public bool IsVillageVisible { get; set; }
    public bool IsZipExtVisible { get; set; }
    public bool IsUSStateVisible { get; set; }
    public bool IsProvinceVisible { get; set; }
    public string ZipPostalLabel { get; set; }
    #endregion

    #region SetAddressTypeEnum Method
    public void SetAddressTypeEnum(string countryCode)
    {
      Entity.CountryCode = countryCode;
      switch (countryCode) {
        case "USA":
        case "US":
          Entity.AddressType = Address.AddressTypeEnum.US;
          break;
        case "GBR":
        case "UK":
          Entity.AddressType = Address.AddressTypeEnum.UK;
          break;
        case "CAN":
          Entity.AddressType = Address.AddressTypeEnum.Canadian;
          break;
        default:
          Entity.AddressType = Address.AddressTypeEnum.Other;
          break;
      }

      SetDisplay(Entity.AddressType);
    }
    #endregion

    #region SetDisplay Method
    public void SetDisplay(Address.AddressTypeEnum addrType)
    {
      ZipPostalLabel = "Postal Code";
      Entity.AddressType = addrType;
      switch (addrType) {
        case Address.AddressTypeEnum.US:
          ZipPostalLabel = "Zip Code";
          IsAddress3Visible = false;
          IsVillageVisible = false;
          IsUSStateVisible = true;
          IsProvinceVisible = false;
          IsZipExtVisible = true;
          break;
        case Address.AddressTypeEnum.Canadian:
          IsAddress3Visible = false;
          IsVillageVisible = false;
          IsUSStateVisible = false;
          IsProvinceVisible = true;
          IsZipExtVisible = false;
          break;
        case Address.AddressTypeEnum.UK:
          IsAddress3Visible = true;
          IsVillageVisible = true;
          IsUSStateVisible = false;
          IsProvinceVisible = false;
          IsZipExtVisible = false;
          break;
        case Address.AddressTypeEnum.Other:
          IsAddress3Visible = true;
          IsVillageVisible = false;
          IsUSStateVisible = false;
          IsProvinceVisible = false;
          IsZipExtVisible = false;
          break;
      }
    }
    #endregion

    #region LoadStates Method
    public List<USState> LoadStates(string fileName)
    {
      USStateManager mgr = new USStateManager();

      States = mgr.BuildCollection(fileName);

      return States;
    }
    #endregion

    #region LoadCountries Method
    public List<Country> LoadCountries(string fileName)
    {
      CountryManager mgr = new CountryManager();

      Countries = mgr.BuildCollection(fileName);

      return Countries;
    }
    #endregion

    #region LoadProvinces Method
    public List<CanadianProvince> LoadProvinces(string fileName)
    {
      CanadianProvinceManager mgr = new CanadianProvinceManager();

      Provinces = mgr.BuildCollection(fileName);

      return Provinces;
    }
    #endregion

    #region Validate Method
    public override bool Validate()
    {
      bool ret = false;

      base.Validate();

      // Validate
      ret = Entity.Validate();
      // Sync validation messages from entity into view model
      ValidationMessages.AddRange(Entity.ValidationMessages);
      IsValid = Entity.IsValid;

      return ret;
    }
    #endregion
  }
}