using System.Collections.Generic;

namespace SamplesData
{
  public class CreditCardViewModel : PDSAViewModelBase
  {
    #region Init Method
    public override void Init()
    {
      base.Init();

      CreditCardTypes = new List<CreditCardType>();
      Entity = new CreditCard();
      LoadMonths();
      LoadYears();
    }
    #endregion

    #region Public Properties
    public List<CreditCardType> CreditCardTypes { get; set; }
    public List<DateMonthData> Months { get; set; }
    public List<int> Years { get; set; }
    public CreditCard Entity { get; set; }
    #endregion

    #region LoadCreditCardTypes Method
    public void LoadCreditCardTypes(string fileName)
    {
      CreditCardTypeManager mgr = new CreditCardTypeManager();

      CreditCardTypes = mgr.BuildCollection(fileName);
    }
    #endregion

    #region LoadMonths Method
    public void LoadMonths()
    {
      DateManager mgr = new DateManager();

      Months = mgr.MonthsLoad();
    }
    #endregion

    #region LoadYears Method
    public void LoadYears()
    {
      DateManager mgr = new DateManager();

      Years = mgr.YearsFutureLoad();
    }
    #endregion

    #region Validate Method
    public override bool Validate()
    {
      bool ret = false;

      base.Validate();

      // Validate
      ret = Entity.Validate();
      // Sync validation messages from entity into view model
      ValidationMessages.AddRange(Entity.ValidationMessages);
      IsValid = Entity.IsValid;

      return ret;
    }
    #endregion
  }
}