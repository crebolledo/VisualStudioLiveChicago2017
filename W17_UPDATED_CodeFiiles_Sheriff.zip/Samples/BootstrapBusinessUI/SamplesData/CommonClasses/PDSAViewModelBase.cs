﻿namespace SamplesData
{
  /// <summary>
  /// Base class for View Model classes
  /// </summary>
  public class PDSAViewModelBase : PDSAEntityBase
  {
    #region Init Method
    public override void Init()
    {
      base.Init();
    }
    #endregion

    #region Validate Method
    /// <summary>
    /// Override this method to validate your entity object
    /// </summary>
    /// <returns>True if entity is valid</returns>
    public override bool Validate()
    {
      return base.Validate();
    }
    #endregion
  }
}
