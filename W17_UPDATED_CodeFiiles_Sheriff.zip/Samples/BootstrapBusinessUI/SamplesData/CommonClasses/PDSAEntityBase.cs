﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity.Validation;
using System.Linq;

namespace SamplesData
{
  /// <summary>
  /// Base class for Entity classes
  /// </summary>
  public class PDSAEntityBase
  {
    #region Constructor
    public PDSAEntityBase()
    {
      Init();
    }
    #endregion

    #region Init Method
    public virtual void Init()
    {
      IsValid = true;
      ValidationMessages = new List<DbValidationError>();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set whether or not this entity is valid
    /// </summary>
    public bool IsValid { get; set; }

    /// <summary>
    /// Get/Set validation messages
    /// </summary>
    public List<DbValidationError> ValidationMessages { get; set; }    
    #endregion

    #region AddModelError Method
    public void AddModelError(string propertyName, string message)
    {
      IsValid = false;
      ValidationMessages.Add(new DbValidationError(propertyName, message));
    }
    #endregion

    #region Validate Method
    /// <summary>
    /// Override this method to validate your entity object
    /// </summary>
    /// <returns>True if entity is valid</returns>
    public virtual bool Validate()
    {
      IsValid = false;
      ValidationMessages.Clear();

      ValidationContext context = new ValidationContext(this, serviceProvider: null, items: null);
      List<ValidationResult> results = new List<ValidationResult>();

      if (!Validator.TryValidateObject(this, context, results, true))
      {
        foreach (ValidationResult item in results)
        {
          ValidationMessages.Add(
            new DbValidationError(item.MemberNames.FirstOrDefault(), item.ErrorMessage));
        }
      }

      IsValid = (ValidationMessages.Count == 0);

      return IsValid;
    }
    #endregion
  }
}
