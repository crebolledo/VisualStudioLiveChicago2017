﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace SamplesData
{
  public class SecurityQuestionManager
  {
    public List<SecurityQuestion> BuildCollection(string fileName)
    {
      List<SecurityQuestion> ret = new List<SecurityQuestion>();
      var xelem = XElement.Load(fileName);

      // Create a list of objects from XElement object
      ret =
        (from node in xelem.Elements("Question")
         select new SecurityQuestion
         {
           Description = node.Element("Description").Value
         }).ToList();

      return ret;
    }
  }
}
