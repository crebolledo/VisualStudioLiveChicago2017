﻿
namespace SamplesData
{
  public class SecurityQuestion
  {
    #region Public Properties
    public string Description { get; set; }
    #endregion
  }
}