﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SamplesData
{
  public class ForgotPasswordData : PDSAEntityBase
  {
    #region Init Method
    public override void Init()
    {
      base.Init();

      Email = string.Empty;
      SecurityQuestion = string.Empty;
      SecurityAnswer = string.Empty;
      IsSecurityAnswerRequired = false;
    }
    #endregion

    #region Public Properties
    public string Email { get; set; }
    public string SecurityQuestion { get; set; }
    public string SecurityAnswer { get; set; }
    public bool IsSecurityAnswerRequired { get; set; }
    #endregion

    #region Validate Method
    public override bool Validate()
    {
      if (string.IsNullOrEmpty(Email)) {
        AddModelError("Email", "Email Address is Required.");
      }

      if (IsSecurityAnswerRequired) {
        if (string.IsNullOrEmpty(SecurityAnswer)) {
          AddModelError("SecurityAnswer", "Security Answer is Required.");
        }
      }
      
      return IsValid;
    }
    #endregion
  }
}
