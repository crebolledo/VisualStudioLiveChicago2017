
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SamplesData
{
  public class CreditCard : PDSAEntityBase
  {
    #region Init Method
    public override void Init()
    {
      base.Init();

      BillingPostalCode = string.Empty;
      CreditCardType = string.Empty;
      NameOnCard = string.Empty;
      _CreditCardNumber = string.Empty;
      ExpMonth = 1;
      ExpYear = DateTime.Now.Year;
      SecurityCode = string.Empty;
    }
    #endregion

    #region Public Properties
    public string BillingPostalCode { get; set; }
    public string CreditCardType { get; set; }
    public string NameOnCard { get; set; }
    public int ExpMonth { get; set; }
    public int ExpYear { get; set; }
    public string SecurityCode { get; set; }

    private string _CreditCardNumber = string.Empty;
    public string CreditCardNumber
    {
      get { return _CreditCardNumber; }
      set { _CreditCardNumber = CleanCreditCard(value); }
    }
    #endregion

    #region Validate Method
    public override bool Validate()
    {
      // Require Name on Card
      if (string.IsNullOrEmpty(NameOnCard))
      {
        AddModelError("NameOnCard", "Name on Card must be filled in.");
      }
      else {
        // No lower case name
        if (NameOnCard.ToLower() == NameOnCard) {
          AddModelError("NameOnCard", "Name on Card must NOT be lower case.");
        }
      }
      // Require Credit Card Type
      if (string.IsNullOrEmpty(CreditCardType))
      {
        AddModelError("CreditCardType", "Credit Card Type must be filled in.");
      }
      // Require Credit Card Number
      if (string.IsNullOrEmpty(CreditCardNumber))
      {
        AddModelError("CreditCardNumber", "Credit Card Number must be filled in.");
      }
      else {
        if (CreditCardNumber.Length < 13) {
          AddModelError("CreditCardNumber", "Credit Card number must be greater than 13 characters.");
        }
      }
      // Require Billing Postal Code
      if (string.IsNullOrEmpty(BillingPostalCode))
      {
        AddModelError("BillingPostalCode", "Billing Postal Code must be filled in.");
      }
      // Require Security Code
      if (string.IsNullOrEmpty(SecurityCode))
      {
        AddModelError("SecurityCode", "Security Code must be filled in.");      
      }
      else {
        if (SecurityCode.Length < 3 || SecurityCode.Length > 4) {
          AddModelError("SecurityCode", "Security Code must be either 3 or 4 characters.");
        }
      }

      return ValidationMessages.Count == 0;
    }
    #endregion

    #region CleanCreditCard Method
    /// <summary>
    /// Remove all formatting characters from a credit card number.
    /// </summary>
    /// <param name="ccNumber">The credit card to clean</param>
    /// <returns>Only numeric digits from a credit card</returns>
    public string CleanCreditCard(string ccNumber)
    {
      if (!string.IsNullOrEmpty(ccNumber))
        return new Regex(@"[^\d]").Replace(ccNumber, "");
      else
        return string.Empty;
    }
    #endregion

    #region ToString Override
    public override string ToString()
    {
      return CreditCardType + " - " + NameOnCard;
    }
    #endregion
  }
}