using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace SamplesData
{
  public class Address : PDSAEntityBase
  {
    #region Enumerations
    public enum AddressTypeEnum : int
    {
      US,
      Canadian,
      UK,
      Other,
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      AddressType = AddressTypeEnum.US;
      Address1 = string.Empty;
      Address2 = string.Empty;
      Address3 = string.Empty;
      City = string.Empty;
      Village = string.Empty;
      StateId = int.MinValue;
      StateCode = string.Empty;
      StateName = string.Empty;
      CountryId = int.MinValue;
      CountryCode = string.Empty;
      CountryName = string.Empty;
      PostalCode = string.Empty;
      PostalCodeExt = string.Empty;
    }
    #endregion

    #region Public Properties
    public AddressTypeEnum AddressType { get; set; }
    [Required(ErrorMessage = "Address 1 is required.")]
    public string Address1 { get; set; }
    public string Address2 { get; set; }
    public string Address3 { get; set; }
    [Required(ErrorMessage = "City is required.")]
    public string City { get; set; }
    public string Village { get; set; }
    public int StateId { get; set; }
    public string StateCode { get; set; }
    public string StateName { get; set; }
    public int CountryId { get; set; }
    public string CountryCode { get; set; }
    public string CountryName { get; set; }
    [Required(ErrorMessage = "Postal Code is required.")]
    public string PostalCode { get; set; }
    public string PostalCodeExt { get; set; }
    #endregion

    #region Validate Method
    public override bool Validate()
    {
      // Address1 lower case?
      if (!string.IsNullOrEmpty(Address1))
      {
        if (Address1.ToLower() == Address1) {
          AddModelError("Address1", "Address 1 must NOT be all lower case.");
        }
      }

      // City lower case?
      if (!string.IsNullOrEmpty(City))
      {
        if (City.ToLower() == City) {
          AddModelError("City", "City must NOT be all lower case.");
        }
      }

      // Require State for Canada and US
      if (this.AddressType == AddressTypeEnum.Canadian | this.AddressType == AddressTypeEnum.US)
      {
        if (string.IsNullOrEmpty(StateName) & string.IsNullOrEmpty(StateCode) & StateId > 0)
        {
          AddModelError("StateCode", "State must be filled in.");
        }
      }

      return IsValid;
    }
    #endregion

    #region GetFullAddress Method
    public string GetFullAddress()
    {
      // Returns an strAddr in the following format
      // 1234 Street
      // PO Box 1234
      // Route(4)
      // City, State 90210-1234

      StringBuilder sb = new StringBuilder(1024);

      sb.AppendLine(Address1);
      if (!string.IsNullOrEmpty(Address2))
      {
        sb.AppendLine(" " + Address2);
      }
      if (!string.IsNullOrEmpty(Address3))
      {
        sb.AppendLine(" " + Address3);
      }

      // Build City, State  PostalCode
      sb.Append(" " + City);
      if (AddressType != AddressTypeEnum.Other)
      {
        if (string.IsNullOrEmpty(StateName))
        {
          sb.Append(", " + StateName);
        }
        else
        {
          sb.Append(", " + StateCode);
        }
      }
      sb.Append("  " + PostalCode);
      if (AddressType != AddressTypeEnum.Other & !string.IsNullOrEmpty(PostalCodeExt))
      {
        sb.Append("-" + PostalCodeExt);
      }
      sb.AppendLine();

      return sb.ToString();
    }
    #endregion

    #region ToString Override
    public override string ToString()
    {
      return GetFullAddress();
    }
    #endregion
  }
}