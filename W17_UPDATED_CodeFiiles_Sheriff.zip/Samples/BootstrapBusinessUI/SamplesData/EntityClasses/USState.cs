﻿
namespace SamplesData
{
  public class USState
  {
    #region Public Properties
    public string StateCodeDisplay { get; set; }
    public string StateCode { get; set; }
    public string StateName { get; set; }
    public string Capital { get; set; }
    #endregion
  }
}