// Use http://mbebenita.github.io/WasmExplorer/index.html to get a .wasm file for this C code.
float multiply(float x, float y) {
  return x * y;
}