Assembling the Web
==================

This is the demo code for my "Assembling the Web - A Tour of WebAssembly" talk.