﻿using PeopleViewer.Presentation;
using PersonRepository.Caching;
using PersonRepository.CSV;
using PersonRepository.Service;
using System.Windows;

namespace PeopleViewer
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            ComposeObjects();
            Application.Current.MainWindow.Show();
        }

        private static void ComposeObjects()
        {
            var wrappedRepo = new ServiceRepository();
            var repository = new CachingRepository(wrappedRepo);
            var viewModel = new MainWindowViewModel(repository);
            Application.Current.MainWindow = new MainWindow(viewModel);
        }
    }
}
