﻿using PeopleViewer.Presentation;
using System.Windows;
using Common;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace PeopleViewer
{
    public partial class App : Application
    {
        IUnityContainer Container;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            ConfigureContainer();
            ComposeObjects();
            Application.Current.MainWindow.Show();
        }

        private void ConfigureContainer()
        {
            Container = new UnityContainer();
            Container.LoadConfiguration();
        }

        private void ComposeObjects()
        {
            Application.Current.MainWindow = Container.Resolve<MainWindow>();
        }
    }
}
