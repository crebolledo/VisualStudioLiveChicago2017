﻿using Common;
using PersonRepository.Service;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Input;

namespace PeopleViewer.Presentation
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        protected IPersonRepository Repository;

        private IEnumerable<Person> _people;
        public IEnumerable<Person> People
        {
            get { return _people; }
            set
            {
                if (_people == value)
                    return;
                _people = value;
                RaisePropertyChanged("People");
            }
        }

        public MainWindowViewModel(IPersonRepository repository)
        {
            Repository = repository;
        }

        public void RefreshPeople()
        {
            People = Repository.GetPeople();
        }

        public void ClearPeople()
        {
            People = new List<Person>();
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
