﻿using System;

namespace ReplacingServices
{
    public class XmlAttribute : Attribute
    { }
}
