CREATE VIEW vwEmployees AS 
  SELECT EmployeeID, LastName + ', ' + FirstName AS EmployeeName 
  FROM Employees
