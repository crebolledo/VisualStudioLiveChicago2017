CREATE VIEW vwGeography AS 
  SELECT DISTINCT PostalCode, City, Region AS State, Country 
  FROM Customers