CREATE VIEW dbo.vwSuppliers
AS
SELECT Products.ProductID, Products.ProductName, 
    Suppliers.CompanyName AS SupplierName
FROM Products INNER JOIN
    Suppliers ON Products.SupplierID = Suppliers.SupplierID