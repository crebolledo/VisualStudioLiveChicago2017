CREATE VIEW vwShippers AS 
  SELECT ShipperId, CompanyName AS ShipperName 
  FROM Shippers
