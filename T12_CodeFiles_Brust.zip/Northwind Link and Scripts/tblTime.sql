if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblTime]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblTime]
GO

CREATE TABLE [dbo].[tblTime] (
	[TimeKey] [int] IDENTITY (1, 1) NOT NULL ,
	[OrderDate] [datetime] NULL ,
	[Year] [int] NULL ,
	[Quarter] [int] NULL ,
	[Month] [int] NULL 
) ON [PRIMARY]
GO

INSERT INTO  tblTime (OrderDate, [Year], [Quarter], [Month])
SELECT DISTINCT OrderDate, YEAR(OrderDate) AS [Year], { fn QUARTER(OrderDate) } AS Quarter, MONTH(OrderDate) AS [Month]
FROM         dbo.Orders
ORDER BY [Year], [Quarter], [Month]