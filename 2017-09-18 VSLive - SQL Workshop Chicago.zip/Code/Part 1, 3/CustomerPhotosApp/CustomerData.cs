﻿namespace CustomerPhotosApp
{
	public class CustomerData
	{
		public int? CustomerId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public byte[] Photo { get; set; }
	}
}
