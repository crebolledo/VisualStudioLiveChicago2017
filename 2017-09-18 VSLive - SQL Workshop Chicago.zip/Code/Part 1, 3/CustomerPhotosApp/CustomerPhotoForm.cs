﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CustomerPhotosApp
{
	public partial class CustomerPhotoForm : Form
	{
		public CustomerPhotoForm()
		{
			InitializeComponent();
		}

		private void SaveButton_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Debugger.Break();

			var customer = new CustomerData
			{
				FirstName = this.FirstNameTextBox.Text,
				LastName = this.LastNameTextBox.Text,
			};

			var photoFilename = this.PhotoTextBox.Text;

			if (!File.Exists(photoFilename))
			{
				MessageBox.Show("Photo file not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			var customerId = CustomerRepo.SaveCustomer(customer, photoFilename);
			MessageBox.Show($"Customer ID {customerId} has been added to the database", "Customer saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void LoadButton_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Debugger.Break();

			var customerId = int.Parse(this.CustomerIdTextBox.Text);
			var customer = CustomerRepo.GetCustomer(customerId);

			this.FirstNameLabel.Text = customer.FirstName;
			this.LastNameLabel.Text = customer.LastName;
			this.CustomerPictureBox.Image = Image.FromStream(new MemoryStream(customer.Photo));
		}
	}
}
