﻿namespace CustomerPhotosApp
{
	partial class CustomerPhotoForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.SaveButton = new System.Windows.Forms.Button();
			this.PhotoTextBox = new System.Windows.Forms.TextBox();
			this.LastNameTextBox = new System.Windows.Forms.TextBox();
			this.FirstNameTextBox = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.CustomerPictureBox = new System.Windows.Forms.PictureBox();
			this.LoadButton = new System.Windows.Forms.Button();
			this.CustomerIdTextBox = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.FirstNameLabel = new System.Windows.Forms.Label();
			this.LastNameLabel = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.CustomerPictureBox)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.SaveButton);
			this.groupBox1.Controls.Add(this.PhotoTextBox);
			this.groupBox1.Controls.Add(this.LastNameTextBox);
			this.groupBox1.Controls.Add(this.FirstNameTextBox);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(24, 12);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.groupBox1.Size = new System.Drawing.Size(772, 292);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "New Customer";
			// 
			// SaveButton
			// 
			this.SaveButton.Location = new System.Drawing.Point(580, 224);
			this.SaveButton.Name = "SaveButton";
			this.SaveButton.Size = new System.Drawing.Size(160, 48);
			this.SaveButton.TabIndex = 6;
			this.SaveButton.Text = "Save";
			this.SaveButton.UseVisualStyleBackColor = true;
			this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
			// 
			// PhotoTextBox
			// 
			this.PhotoTextBox.Location = new System.Drawing.Point(232, 168);
			this.PhotoTextBox.Name = "PhotoTextBox";
			this.PhotoTextBox.Size = new System.Drawing.Size(508, 49);
			this.PhotoTextBox.TabIndex = 5;
			// 
			// LastNameTextBox
			// 
			this.LastNameTextBox.Location = new System.Drawing.Point(232, 112);
			this.LastNameTextBox.Name = "LastNameTextBox";
			this.LastNameTextBox.Size = new System.Drawing.Size(508, 49);
			this.LastNameTextBox.TabIndex = 4;
			// 
			// FirstNameTextBox
			// 
			this.FirstNameTextBox.Location = new System.Drawing.Point(232, 56);
			this.FirstNameTextBox.Name = "FirstNameTextBox";
			this.FirstNameTextBox.Size = new System.Drawing.Size(508, 49);
			this.FirstNameTextBox.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(28, 172);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(116, 42);
			this.label3.TabIndex = 2;
			this.label3.Text = "Photo";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(28, 116);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(192, 42);
			this.label2.TabIndex = 1;
			this.label2.Text = "Last name";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(28, 60);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(193, 42);
			this.label1.TabIndex = 0;
			this.label1.Text = "First name";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.LastNameLabel);
			this.groupBox2.Controls.Add(this.FirstNameLabel);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.CustomerPictureBox);
			this.groupBox2.Controls.Add(this.LoadButton);
			this.groupBox2.Controls.Add(this.CustomerIdTextBox);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Location = new System.Drawing.Point(24, 308);
			this.groupBox2.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.groupBox2.Size = new System.Drawing.Size(772, 484);
			this.groupBox2.TabIndex = 7;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Existing Customer";
			// 
			// CustomerPictureBox
			// 
			this.CustomerPictureBox.Location = new System.Drawing.Point(264, 228);
			this.CustomerPictureBox.Name = "CustomerPictureBox";
			this.CustomerPictureBox.Size = new System.Drawing.Size(484, 232);
			this.CustomerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.CustomerPictureBox.TabIndex = 7;
			this.CustomerPictureBox.TabStop = false;
			// 
			// LoadButton
			// 
			this.LoadButton.Location = new System.Drawing.Point(432, 56);
			this.LoadButton.Name = "LoadButton";
			this.LoadButton.Size = new System.Drawing.Size(160, 48);
			this.LoadButton.TabIndex = 6;
			this.LoadButton.Text = "Load";
			this.LoadButton.UseVisualStyleBackColor = true;
			this.LoadButton.Click += new System.EventHandler(this.LoadButton_Click);
			// 
			// CustomerIdTextBox
			// 
			this.CustomerIdTextBox.Location = new System.Drawing.Point(268, 56);
			this.CustomerIdTextBox.Name = "CustomerIdTextBox";
			this.CustomerIdTextBox.Size = new System.Drawing.Size(152, 49);
			this.CustomerIdTextBox.TabIndex = 3;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(28, 60);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(225, 42);
			this.label6.TabIndex = 0;
			this.label6.Text = "Customer ID";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(28, 172);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(192, 42);
			this.label4.TabIndex = 9;
			this.label4.Text = "Last name";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(28, 116);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(193, 42);
			this.label5.TabIndex = 8;
			this.label5.Text = "First name";
			// 
			// FirstNameLabel
			// 
			this.FirstNameLabel.Location = new System.Drawing.Point(268, 116);
			this.FirstNameLabel.Name = "FirstNameLabel";
			this.FirstNameLabel.Size = new System.Drawing.Size(348, 48);
			this.FirstNameLabel.TabIndex = 10;
			// 
			// LastNameLabel
			// 
			this.LastNameLabel.Location = new System.Drawing.Point(268, 168);
			this.LastNameLabel.Name = "LastNameLabel";
			this.LastNameLabel.Size = new System.Drawing.Size(348, 48);
			this.LastNameLabel.TabIndex = 11;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(28, 228);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(116, 42);
			this.label7.TabIndex = 12;
			this.label7.Text = "Photo";
			// 
			// CustomerPhotoForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(818, 817);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.Name = "CustomerPhotoForm";
			this.Text = "CustomerPhotoForm";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.CustomerPictureBox)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button SaveButton;
		private System.Windows.Forms.TextBox PhotoTextBox;
		private System.Windows.Forms.TextBox LastNameTextBox;
		private System.Windows.Forms.TextBox FirstNameTextBox;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.PictureBox CustomerPictureBox;
		private System.Windows.Forms.Button LoadButton;
		private System.Windows.Forms.TextBox CustomerIdTextBox;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label LastNameLabel;
		private System.Windows.Forms.Label FirstNameLabel;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label7;
	}
}