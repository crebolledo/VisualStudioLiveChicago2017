﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Transactions;

namespace CustomerPhotosApp
{
	public static class CustomerRepo
	{
		private const string ConnStr =
		  "Data Source=.;Integrated Security=True;Initial Catalog=HolDb;";

		public static int SaveCustomer(CustomerData customer, string photoFilename)
		{
			var customerId = default(int);

			const string TSql = @"
				INSERT INTO Customer(FirstName, LastName, Photo)
					OUTPUT
						inserted.CustomerId,
						inserted.Photo.PathName(),
						GET_FILESTREAM_TRANSACTION_CONTEXT()
					SELECT @FirstName, @LastName, 0x";

			using (var conn = new SqlConnection(ConnStr))
			{
				using (var cmd = new SqlCommand(TSql, conn))
				{
					using (var ts = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(0, 5, 0)))
					{
						cmd.Parameters.AddWithValue("@FirstName", customer.FirstName);
						cmd.Parameters.AddWithValue("@LastName", customer.LastName);

						var serverPathName = default(string);
						var serverTxnContext = default(byte[]);

						conn.Open();
						using (var rdr = cmd.ExecuteReader(CommandBehavior.SingleRow))
						{
							rdr.Read();
							customerId = rdr.GetInt32(0);
							serverPathName = rdr.GetSqlString(1).Value;
							serverTxnContext = rdr.GetSqlBinary(2).Value;
							rdr.Close();
						}
						conn.Close();

						using (var source = new FileStream(photoFilename, FileMode.Open, FileAccess.Read))
						{
							using (var dest = new SqlFileStream(serverPathName, serverTxnContext, FileAccess.Write))
							{
								source.CopyTo(dest, 4096);
								dest.Close();
							}
							source.Close();
						}

						ts.Complete();
					}
				}
			}

			return customerId;
		}

		public static CustomerData GetCustomer(int customerId)
		{
			var customer = new CustomerData { CustomerId = customerId };

			const string TSql = @"
				SELECT FirstName, LastName, Photo.PathName(), GET_FILESTREAM_TRANSACTION_CONTEXT()
					FROM Customer
					WHERE CustomerId = @CustomerId";

			using (var conn = new SqlConnection(ConnStr))
			{
				using (var cmd = new SqlCommand(TSql, conn))
				{
					using (var ts = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(0, 5, 0)))
					{
						cmd.Parameters.AddWithValue("@CustomerId", customerId);

						var serverPathName = default(string);   // string to hold the BLOB pathname
						var serverTxnContext = default(byte[]); // byte array to hold the txn context

						conn.Open();
						using (var rdr = cmd.ExecuteReader(CommandBehavior.SingleRow))
						{
							rdr.Read();
							customer.FirstName = rdr.GetSqlString(0).Value;
							customer.LastName = rdr.GetSqlString(1).Value;
							serverPathName = rdr.GetSqlString(2).Value;
							serverTxnContext = rdr.GetSqlBinary(3).Value;
							rdr.Close();
						}
						conn.Close();

						using (var source = new SqlFileStream(serverPathName, serverTxnContext, FileAccess.Read))
						{
							using (var dest = new MemoryStream())
							{
								source.CopyTo(dest, 4096);
								dest.Close();
								customer.Photo = dest.ToArray();
							}
							source.Close();
						}

						ts.Complete();
					}
				}
			}

			return customer;
		}

	}
}
