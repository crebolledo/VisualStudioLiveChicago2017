﻿namespace HolContent
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.ContentTreeView = new System.Windows.Forms.TreeView();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.BackupLabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.RestoreLabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.TreeToolStripDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
			this.TreeCollapseAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.TreeExpandAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ContentTextBox = new System.Windows.Forms.TextBox();
			this.toolStrip2 = new System.Windows.Forms.ToolStrip();
			this.CopyToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.CopyAllToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.contextMenuStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.toolStrip1.SuspendLayout();
			this.toolStrip2.SuspendLayout();
			this.SuspendLayout();
			// 
			// ContentTreeView
			// 
			this.ContentTreeView.ContextMenuStrip = this.contextMenuStrip1;
			this.ContentTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ContentTreeView.HideSelection = false;
			this.ContentTreeView.Location = new System.Drawing.Point(0, 39);
			this.ContentTreeView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.ContentTreeView.Name = "ContentTreeView";
			this.ContentTreeView.ShowLines = false;
			this.ContentTreeView.Size = new System.Drawing.Size(375, 678);
			this.ContentTreeView.TabIndex = 0;
			this.ContentTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.ContentTreeView_AfterSelect);
			this.ContentTreeView.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.ContentTreeView_NodeMouseClick);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BackupLabToolStripMenuItem,
            this.RestoreLabToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(245, 120);
			this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
			// 
			// BackupLabToolStripMenuItem
			// 
			this.BackupLabToolStripMenuItem.Name = "BackupLabToolStripMenuItem";
			this.BackupLabToolStripMenuItem.Size = new System.Drawing.Size(244, 36);
			this.BackupLabToolStripMenuItem.Text = "Backup lab";
			this.BackupLabToolStripMenuItem.Click += new System.EventHandler(this.BackupLabToolStripMenuItem_Click);
			// 
			// RestoreLabToolStripMenuItem
			// 
			this.RestoreLabToolStripMenuItem.Name = "RestoreLabToolStripMenuItem";
			this.RestoreLabToolStripMenuItem.Size = new System.Drawing.Size(244, 36);
			this.RestoreLabToolStripMenuItem.Text = "Restore lab";
			this.RestoreLabToolStripMenuItem.Click += new System.EventHandler(this.RestoreLabToolStripMenuItem_Click);
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.ContentTreeView);
			this.splitContainer1.Panel1.Controls.Add(this.toolStrip1);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.ContentTextBox);
			this.splitContainer1.Panel2.Controls.Add(this.toolStrip2);
			this.splitContainer1.Size = new System.Drawing.Size(1130, 717);
			this.splitContainer1.SplitterDistance = 375;
			this.splitContainer1.SplitterWidth = 5;
			this.splitContainer1.TabIndex = 1;
			// 
			// toolStrip1
			// 
			this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.TreeToolStripDropDownButton});
			this.toolStrip1.Location = new System.Drawing.Point(0, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(375, 39);
			this.toolStrip1.TabIndex = 1;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
			// 
			// TreeToolStripDropDownButton
			// 
			this.TreeToolStripDropDownButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.TreeToolStripDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TreeCollapseAllToolStripMenuItem,
            this.TreeExpandAllToolStripMenuItem});
			this.TreeToolStripDropDownButton.Image = ((System.Drawing.Image)(resources.GetObject("TreeToolStripDropDownButton.Image")));
			this.TreeToolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TreeToolStripDropDownButton.Name = "TreeToolStripDropDownButton";
			this.TreeToolStripDropDownButton.Size = new System.Drawing.Size(82, 36);
			this.TreeToolStripDropDownButton.Text = "Tree";
			// 
			// TreeCollapseAllToolStripMenuItem
			// 
			this.TreeCollapseAllToolStripMenuItem.Name = "TreeCollapseAllToolStripMenuItem";
			this.TreeCollapseAllToolStripMenuItem.Size = new System.Drawing.Size(235, 38);
			this.TreeCollapseAllToolStripMenuItem.Text = "Collapse all";
			this.TreeCollapseAllToolStripMenuItem.Click += new System.EventHandler(this.TreeCollapseAllToolStripMenuItem_Click);
			// 
			// TreeExpandAllToolStripMenuItem
			// 
			this.TreeExpandAllToolStripMenuItem.Name = "TreeExpandAllToolStripMenuItem";
			this.TreeExpandAllToolStripMenuItem.Size = new System.Drawing.Size(235, 38);
			this.TreeExpandAllToolStripMenuItem.Text = "Expand all";
			this.TreeExpandAllToolStripMenuItem.Click += new System.EventHandler(this.TreeExpandAllToolStripMenuItem_Click);
			// 
			// ContentTextBox
			// 
			this.ContentTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ContentTextBox.Font = new System.Drawing.Font("Consolas", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ContentTextBox.Location = new System.Drawing.Point(0, 39);
			this.ContentTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.ContentTextBox.Multiline = true;
			this.ContentTextBox.Name = "ContentTextBox";
			this.ContentTextBox.ReadOnly = true;
			this.ContentTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.ContentTextBox.Size = new System.Drawing.Size(750, 678);
			this.ContentTextBox.TabIndex = 0;
			this.ContentTextBox.WordWrap = false;
			// 
			// toolStrip2
			// 
			this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip2.ImageScalingSize = new System.Drawing.Size(32, 32);
			this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CopyToolStripButton,
            this.CopyAllToolStripButton});
			this.toolStrip2.Location = new System.Drawing.Point(0, 0);
			this.toolStrip2.Name = "toolStrip2";
			this.toolStrip2.Size = new System.Drawing.Size(750, 39);
			this.toolStrip2.TabIndex = 2;
			this.toolStrip2.Text = "toolStrip2";
			// 
			// CopyToolStripButton
			// 
			this.CopyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.CopyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("CopyToolStripButton.Image")));
			this.CopyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.CopyToolStripButton.Name = "CopyToolStripButton";
			this.CopyToolStripButton.Size = new System.Drawing.Size(74, 36);
			this.CopyToolStripButton.Text = "Copy";
			this.CopyToolStripButton.Click += new System.EventHandler(this.CopyToolStripButton_Click);
			// 
			// CopyAllToolStripButton
			// 
			this.CopyAllToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.CopyAllToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("CopyAllToolStripButton.Image")));
			this.CopyAllToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.CopyAllToolStripButton.Name = "CopyAllToolStripButton";
			this.CopyAllToolStripButton.Size = new System.Drawing.Size(105, 36);
			this.CopyAllToolStripButton.Text = "Copy all";
			this.CopyAllToolStripButton.Click += new System.EventHandler(this.CopyAllToolStripButton_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 37F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1130, 717);
			this.Controls.Add(this.splitContainer1);
			this.Font = new System.Drawing.Font("Segoe UI", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "MainForm";
			this.Text = "Lab Content";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.contextMenuStrip1.ResumeLayout(false);
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.toolStrip2.ResumeLayout(false);
			this.toolStrip2.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TreeView ContentTreeView;
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.TextBox ContentTextBox;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStrip toolStrip2;
		private System.Windows.Forms.ToolStripButton CopyAllToolStripButton;
		private System.Windows.Forms.ToolStripButton CopyToolStripButton;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripDropDownButton TreeToolStripDropDownButton;
		private System.Windows.Forms.ToolStripMenuItem TreeCollapseAllToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem TreeExpandAllToolStripMenuItem;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem BackupLabToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem RestoreLabToolStripMenuItem;
	}
}

