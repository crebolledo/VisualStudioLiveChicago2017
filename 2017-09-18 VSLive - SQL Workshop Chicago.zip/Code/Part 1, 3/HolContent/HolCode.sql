﻿-- Developer Dive into SQL Server 2016

/* LAB */
-- Setup

/* STEP */
-- Create database with partial containment

REVERT
GO

USE master
GO

IF (SELECT COUNT(*) FROM sys.databases WHERE name = 'HolDb') = 1 BEGIN
	ALTER DATABASE HolDb SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE HolDb
END

EXEC sp_configure 'contained database authentication', 1
GO
RECONFIGURE
GO

CREATE DATABASE HolDb CONTAINMENT = PARTIAL
GO

/* STEP */
-- Create tables and views

USE HolDb
GO

CREATE TABLE SalesUser(
	SalesUserId int IDENTITY,
	Username varchar(50),
	FirstName varchar(50),
	LastName varchar(50),
	Phone varchar(12),
	Email varchar(100),
	DateOfBirth date,
	CONSTRAINT PK_SalesUser PRIMARY KEY (SalesUserId)
)

SET IDENTITY_INSERT SalesUser ON
INSERT INTO SalesUser (SalesUserId, Username, FirstName, LastName, Phone, Email, DateOfBirth) VALUES 
 (1, 'jadams', 'Jay', 'Adams', '473-555-0117', 'jay.adams@corp.com', DATEFROMPARTS(1986, 6, 13)),
 (2, 'jgalvin', 'Janice', 'Galvin', '465-555-0156', 'janice.galvin@corp.com.co', DATEFROMPARTS(1964, 8, 30)),
 (3, 'dmu', 'Dan', 'Mu', '970-555-0138', 'dan.mu@corp.net', DATEFROMPARTS(1969, 9, 26)),
 (4, 'jsmith', 'Jane', 'Smith', '913-555-0172', 'jane.smith@hotmail.com', DATEFROMPARTS(1989, 3, 13)),
 (5, 'djones', 'Danny', 'Jones', '150-555-0189', 'danny.jones@hotmail.com', DATEFROMPARTS(1992, 5, 27))
SET IDENTITY_INSERT SalesUser OFF

CREATE TABLE Customer(
	CustomerId int IDENTITY,
	FirstName varchar(50),
	LastName varchar(50),
	Phone varchar(12),
	Email varchar(100),
	SocialSecurityNumber varchar(11),
	Balance money,
	CONSTRAINT PK_Customer PRIMARY KEY (CustomerId)
)

SET IDENTITY_INSERT Customer ON
INSERT INTO Customer (CustomerId, FirstName, LastName, Phone, Email, SocialSecurityNumber, Balance) VALUES
 (1, 'Ken', 'Sanchez', '697-555-0142', 'ksanchez@hotmail.com', '068453678', 327.5),
 (2, 'Terri', 'Duffy', '819-555-0175', 'tduff@gmail.com', '257001369', 102.95),
 (3, 'Gail', 'Erickson', '212-555-0187', 'gerickson@outlook.com', '981554877', 811.41),
 (4, 'Jossef', 'Goldberg', '612-555-0100', 'jgoldberg@hotmail.com', '068453678', 0),
 (5, 'Dylan', 'Miller', '849-555-0139', 'dmiller@gmail.com', '257001369', 24.95),
 (6, 'Diane', 'Margheim', '122-555-0189', 'dmargheim@outlook.com', '981554877', 896.6),
 (7, 'Gigi', 'Matthew', '181-555-0156', 'gmatthew@hotmail.com', '068453678', 30),
 (8, 'Michael', 'Raheem', '815-555-0138', 'mraheem@gmail.com', '257001369', 35.36),
 (9, 'Sharon', 'Salavaria', '185-555-0186', 'ssalavaria@outlook.com', '981554877', 93.1),
 (10, 'Kevin', 'Brown', '330-555-2568', 'kbrown@hotmail.com', '068453678', 45.6),
 (11, 'Mary', 'Dempsey', '719-555-0181', 'mdempsey@gmail.com', '257001369', 100),
 (12, 'Jill', 'Williams', '168-555-0183', 'jwilliams@outlook.com', '981554877', 1102.6)
SET IDENTITY_INSERT Customer OFF

CREATE TABLE SalesOrder(
    SalesOrderId int IDENTITY,
    SalesUserId int,
	CustomerId int,
    Product varchar(10),
    Qty int,
	CreatedAt datetime2 CONSTRAINT DF_SalesOrder_CreatedAt DEFAULT SYSUTCDATETIME()
	CONSTRAINT PK_SalesOrder PRIMARY KEY (SalesOrderId),
	CONSTRAINT FK_SalesOrder_SalesUser FOREIGN KEY (SalesUserId) REFERENCES SalesUser(SalesUserId),
	CONSTRAINT FK_SalesOrder_Customer FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerId)
)

SET IDENTITY_INSERT SalesOrder ON
INSERT INTO SalesOrder (SalesOrderId, SalesUserId, CustomerId, Product, Qty, CreatedAt) VALUES 
	(1, 2, 4, 'Valve', 5, DATEADD(s, -1200, SYSUTCDATETIME())), 
	(2, 2, 9, 'Wheel', 2, DATEADD(s, -1000, SYSUTCDATETIME())),  
	(3, 2, 2, 'Valve', 4, DATEADD(s, -800, SYSUTCDATETIME())), 
	(4, 3, 6, 'Bracket', 2, DATEADD(s, -600, SYSUTCDATETIME())), 
	(5, 3, 4, 'Wheel', 5, DATEADD(s, -400, SYSUTCDATETIME())), 
	(6, 3, 11, 'Seat', 5, DATEADD(s, -200, SYSUTCDATETIME()))
SET IDENTITY_INSERT SalesOrder OFF

GO

CREATE VIEW SalesOrderView
AS
	SELECT
		so.SalesOrderId,
		so.SalesUserId,
		su.Username,
		EmployeeName = CONCAT(su.LastName, ', ', su.FirstName),
		so.CustomerId,
		CustomerName = CONCAT(c.LastName, ', ', c.FirstName),
		so.Product,
		so.Qty,
		CreatedAt = SWITCHOFFSET(so.CreatedAt, '-08:00')
	FROM
		SalesOrder AS so
		INNER JOIN SalesUser AS su ON su.SalesUserId = so.SalesUserId
		INNER JOIN Customer AS c ON c.CustomerId = so.CustomerId
GO


/* LAB */
-- Dynamic Data Masking (DDM)

/* STEP */
-- Mask columns

USE HolDb
GO

-- Partially mask customer first name
ALTER TABLE Customer 
 ALTER COLUMN FirstName
 ADD MASKED WITH (FUNCTION='partial(2, "...", 2)')

-- Partially mask customer last name
ALTER TABLE Customer 
 ALTER COLUMN LastName
 ADD MASKED WITH (FUNCTION='partial(1, "...", 0)')

-- Partially mask customer email address
ALTER TABLE Customer 
 ALTER COLUMN Email
 ADD MASKED WITH (FUNCTION='email()')

-- Fully mask customer phone number
ALTER TABLE Customer 
 ALTER COLUMN Phone
 ADD MASKED WITH (FUNCTION='default()')

-- Randomly mask customer balance
ALTER TABLE Customer 
 ALTER COLUMN Balance
 ADD MASKED WITH (FUNCTION='random(0, 1000)')

-- Fully mask sales user date of birth
ALTER TABLE SalesUser
 ALTER COLUMN DateOfBirth
 ADD MASKED WITH (FUNCTION='default()')

-- Partially mask sales user phone number
ALTER TABLE SalesUser
 ALTER COLUMN Phone
 ADD MASKED WITH (FUNCTION='partial(0, "___-___-", 4)')

-- Discover all masked column in the database
SELECT
	t.name AS TableName,
	mc.name AS ColumnName,
	mc.masking_function AS MaskingFunction
FROM
	sys.masked_columns AS mc
	INNER JOIN sys.tables AS t ON mc.[object_id] = t.[object_id]

-- Query from table with masked columns
SELECT * FROM Customer

/* STEP */
-- Create users and permissions

-- Create view to show users and their permissions
GO
CREATE VIEW UsersView AS
SELECT
	Username		= pr.name,
	LoginName		= l.loginname,
	LoginType		= pr.type_desc,
	PermissionState	= pe.state_desc,
	PermissionName	= pe.permission_name,
	PermissionClass	= pe.class_desc,
	ObjectName		= o.name,
	ObjectType		= o.type_desc
FROM
	sys.database_principals AS pr
	INNER JOIN sys.database_permissions AS pe ON pe.grantee_principal_id = pr.principal_id
	INNER JOIN sys.sysusers AS u ON u.uid = pr.principal_id
	LEFT OUTER JOIN sys.objects AS o ON o.object_id = pe.major_id
	LEFT OUTER JOIN master..syslogins AS l ON u.sid = l.sid
WHERE
	pr.type_desc IN ('WINDOWS_USER', 'SQL_USER', 'DATABASE_ROLE') AND pr.name != 'public'
GO

-- The currently connected login is mapped to user dbo, with full permissions implied
SELECT * FROM UsersView ORDER BY Username, ObjectName, PermissionName

-- Create sales users
CREATE USER jadams	WITH PASSWORD = 'ja_p@$$w0rd'
CREATE USER jgalvin	WITH PASSWORD = 'jg_p@$$w0rd'
CREATE USER dmu		WITH PASSWORD = 'dm_p@$$w0rd'
CREATE USER jsmith	WITH PASSWORD = 'js_p@$$w0rd'
CREATE USER djones	WITH PASSWORD = 'dj_p@$$w0rd'

-- Create developer users
CREATE USER dev1	WITH PASSWORD = 'd1_p@$$w0rd'
CREATE USER dev2	WITH PASSWORD = 'd2_p@$$w0rd'

-- Assign users to roles
CREATE ROLE SalesUsers AUTHORIZATION dbo
CREATE ROLE DevUsers AUTHORIZATION dbo

EXEC sp_addrolemember SalesUsers, jadams
EXEC sp_addrolemember SalesUsers, jgalvin
EXEC sp_addrolemember SalesUsers, dmu
EXEC sp_addrolemember SalesUsers, jsmith
EXEC sp_addrolemember SalesUsers, djones

EXEC sp_addrolemember DevUsers, dev1
EXEC sp_addrolemember DevUsers, dev2

-- Both sales users and developers can query the tables
-- Only sales users can view unmasked data; developers can only view masked data
GRANT SELECT ON Customer TO SalesUsers
GRANT SELECT ON SalesUser TO SalesUsers
GRANT SELECT ON Customer TO DevUsers
GRANT SELECT ON SalesUser TO DevUsers
GRANT UNMASK TO SalesUsers
SELECT * FROM UsersView ORDER BY Username, ObjectName, PermissionName

/* STEP */
-- Impersonate different users

-- Impersonate a sales user
EXECUTE AS USER = 'jgalvin'
SELECT * FROM Customer
SELECT * FROM SalesUser
REVERT

-- Impersonate a developer
EXECUTE AS USER = 'dev1'
SELECT * FROM Customer
SELECT * FROM SalesUser
REVERT

-- Let a single developer view unmasked data
GRANT UNMASK TO dev1
SELECT * FROM UsersView ORDER BY Username, ObjectName, PermissionName

-- Developer dev1 can view unmasked data
EXECUTE AS USER = 'dev1'
SELECT * FROM Customer
SELECT * FROM SalesUser
REVERT

-- Other developers can still only view masked data
EXECUTE AS USER = 'dev2'
SELECT * FROM Customer
SELECT * FROM SalesUser
REVERT

-- No longer allow developer dev1 to view unmasked data
REVOKE UNMASK FROM dev1
EXECUTE AS USER = 'dev1'
SELECT * FROM Customer
SELECT * FROM SalesUser
REVERT

/* STEP */
-- Different masking functions with different data types

CREATE TABLE MaskingPoc(
	Label varchar(32) NOT NULL,
	-- "default" provides full masking of all data types
	default_varchar			varchar(100)	MASKED WITH (FUNCTION = 'default()') DEFAULT('varchar string'),
	default_char			char(20)		MASKED WITH (FUNCTION = 'default()') DEFAULT('char string'),
	default_text			text			MASKED WITH (FUNCTION = 'default()') DEFAULT('text string'),
	default_bit				bit				MASKED WITH (FUNCTION = 'default()') DEFAULT(0),
	default_int				int				MASKED WITH (FUNCTION = 'default()') DEFAULT(256),
	default_bigint			bigint			MASKED WITH (FUNCTION = 'default()') DEFAULT(2560),
	default_decimal			decimal			MASKED WITH (FUNCTION = 'default()') DEFAULT(5.5),
	default_date			date			MASKED WITH (FUNCTION = 'default()') DEFAULT(SYSDATETIME()),
	default_time			time			MASKED WITH (FUNCTION = 'default()') DEFAULT(SYSDATETIME()),
	default_datetime2		datetime2		MASKED WITH (FUNCTION = 'default()') DEFAULT(SYSDATETIME()),
	default_datetimeoffset	datetimeoffset	MASKED WITH (FUNCTION = 'default()') DEFAULT(SYSDATETIME()),
	default_varbinary		varbinary(max)	MASKED WITH (FUNCTION = 'default()') DEFAULT(0x424F),
	default_xml				xml				MASKED WITH (FUNCTION = 'default()') DEFAULT('<sample>hello</sample>'),
	default_hierarchyid		hierarchyid		MASKED WITH (FUNCTION = 'default()') DEFAULT('/1/2/3/'),
	default_geography		geography		MASKED WITH (FUNCTION = 'default()') DEFAULT('POINT(0 0)'),
	default_geometry		geometry		MASKED WITH (FUNCTION = 'default()') DEFAULT('LINESTRING(0 0, 5 5)'),
	-- "partial" provides partial masking of string data types
	partial_varchar			varchar(100)	MASKED WITH (FUNCTION = 'partial(2, "...", 2)') DEFAULT('varchar string'),
	partial_char			char(20)		MASKED WITH (FUNCTION = 'partial(2, "...", 2)') DEFAULT('char string'),
	partial_text			text			MASKED WITH (FUNCTION = 'partial(2, "...", 2)') DEFAULT('text string'),
	-- "email" provides email-format masking of string data types
	email_varchar			varchar(100)	MASKED WITH (FUNCTION = 'email()') DEFAULT('varchar string'),
	email_char				char(20)		MASKED WITH (FUNCTION = 'email()') DEFAULT('char string'),
	email_text				text			MASKED WITH (FUNCTION = 'email()') DEFAULT('text string'),
	-- "partial" can simulate "email"
	partial_email_varchar	varchar(100)	MASKED WITH (FUNCTION = 'partial(1, "XXX@XXXX.com", 0)') DEFAULT('varchar email string'),
	-- "random" provides random masking of numeric data types
	random_bit				bit				MASKED WITH (FUNCTION = 'random(0, 1)') DEFAULT(0),
	random_int				int				MASKED WITH (FUNCTION = 'random(1, 12)') DEFAULT(256),
	random_bigint			bigint			MASKED WITH (FUNCTION = 'random(1001, 999999)') DEFAULT(2560),
	random_decimal			decimal			MASKED WITH (FUNCTION = 'random(100, 200)') DEFAULT(5.5))

-- Populate table
INSERT INTO MaskingPoc (Label) VALUES ('Row1'), ('Row2'), ('Row3'), ('Row4'), ('Row5'), ('Row6')

-- View unmasked data
SELECT * FROM MaskingPoc
SELECT USER_NAME()

-- View masked data
GRANT SELECT ON MaskingPoc TO DevUsers

-- For developers, the data is masked
EXECUTE AS USER = 'dev1'
SELECT * FROM MaskingPoc
SELECT * FROM MaskingPoc
REVERT
GO

-- Cleanup POC
DROP TABLE MaskingPoc
GO


/* LAB */
-- Row-Level Security (RLS), part 1

/* STEP */
-- Grant basic permissions

USE HolDb
GO

-- View all the rows in the SalesOrder table
SELECT * FROM SalesOrder
SELECT * FROM SalesOrderView

-- View current users and permissions
SELECT * FROM UsersView ORDER BY Username, ObjectName, PermissionName
SELECT * FROM UsersView WHERE ObjectName = 'SalesOrder' ORDER BY Username, ObjectName, PermissionName

-- Grant SELECT access to the SalesOrder table for all sales users 
GRANT SELECT ON SalesOrder TO SalesUsers
GRANT SELECT ON SalesOrderView TO SalesUsers

-- Grant full access to the SalesOrder table to the manager
GRANT INSERT, UPDATE, DELETE ON SalesOrder TO jadams

-- Sales users can SELECT, manager can also INSERT, UPDATE, DELETE
SELECT * FROM UsersView WHERE ObjectName = 'SalesOrder' ORDER BY Username, ObjectName, PermissionName

-- Everyone can see everything
EXECUTE AS USER = 'jgalvin'
SELECT * FROM SalesOrderView
REVERT

EXECUTE AS USER = 'dmu'
SELECT * FROM SalesOrderView
REVERT

GO

/* STEP */
-- Create predicate function

-- Create a new schema for security objects
CREATE SCHEMA sec
GO

-- Create an RLS predicate function (implement the security logic)
CREATE FUNCTION sec.SalesOrderPredicate(@SalesUserId AS int)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN
		SELECT
			1 AS result
		WHERE
			DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID((SELECT Username FROM dbo.SalesUser WHERE SalesUserId = @SalesUserId)) OR
			DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID('jadams')
GO

/* STEP */
-- Test predicate function (optional)

SELECT * FROM sec.SalesOrderPredicate(2)					-- FALSE, no username match on dbo
SELECT USER_NAME()											-- The current connection username is dbo

-- Test it for Janice
EXECUTE AS USER = 'jgalvin'									-- Run as Janice
IF 0 = 1 BEGIN
	SELECT * FROM sec.SalesOrderPredicate(2)				-- Fails, user can't SELECT from predicate function
END
REVERT														-- Run as dbo

GRANT SELECT ON sec.SalesOrderPredicate TO jgalvin			-- Temporarily grant permission to test predicate function (never do this!)
EXECUTE AS USER = 'jgalvin'									-- Run as Janice
SELECT * FROM sec.SalesOrderPredicate(2)					-- TRUE
SELECT * FROM sec.SalesOrderPredicate(3)					-- FALSE
REVERT														-- Run as dbo
REVOKE SELECT ON sec.SalesOrderPredicate FROM jgalvin		-- Revoke permission

-- Test it for Dan
GRANT SELECT ON sec.SalesOrderPredicate TO dmu				-- Temporarily grant permission to test predicate function (never do this!)
EXECUTE AS USER = 'dmu'										-- Run as Dan
SELECT * FROM sec.SalesOrderPredicate(2)					-- FALSE
SELECT * FROM sec.SalesOrderPredicate(3)					-- TRUE
REVERT														-- Run as dbo
REVOKE SELECT ON sec.SalesOrderPredicate FROM dmu			-- Revoke permission

-- Test it for Jay (the manager)
GRANT SELECT ON sec.SalesOrderPredicate TO jadams			-- Temporarily grant permission to test predicate function (never do this!)
EXECUTE AS USER = 'jadams'									-- Run as ManagerUser
SELECT * FROM sec.SalesOrderPredicate(2)					-- TRUE
SELECT * FROM sec.SalesOrderPredicate(3)					-- TRUE
REVERT														-- Run as dbo
REVOKE SELECT ON sec.SalesOrderPredicate FROM jadams		-- Revoke permission

/* STEP */
-- Create security policy

-- Bind the predication function to the table
CREATE SECURITY POLICY sec.SalesOrderPolicy
	ADD FILTER PREDICATE sec.SalesOrderPredicate(SalesUserId) 
	ON dbo.SalesOrder
	WITH (STATE = ON)

/* STEP */
-- Test RLS by impersonation

-- Janice can only see her orders
EXECUTE AS USER = 'jgalvin'
SELECT * FROM SalesOrderView
SELECT * FROM SalesOrder
SELECT COUNT(*) FROM SalesOrder
REVERT

-- Dan can only see his orders
EXECUTE AS USER = 'dmu'
SELECT * FROM SalesOrderView
SELECT * FROM SalesOrder
SELECT COUNT(*) FROM SalesOrder
REVERT

-- Jay (manager) can see all orders
EXECUTE AS USER = 'jadams'
SELECT * FROM SalesOrderView
SELECT * FROM SalesOrder
SELECT COUNT(*) FROM SalesOrder
REVERT

-- Janice (and all other sales users except Jay the manager) can't insert/update/delete
IF 0 = 1 BEGIN
	EXECUTE AS USER = 'jgalvin'
	INSERT SalesOrder VALUES (2, 3, 'Valve', 5, SYSUTCDATETIME())
	UPDATE SalesOrder SET Product = 'Screw' WHERE SalesOrderId = 3
	DELETE SalesOrder WHERE SalesOrderId = 2
	REVERT
END

-- Jay the manager has full access
EXECUTE AS USER = 'jadams'
INSERT SalesOrder VALUES (3, 10, 'Valve', 1, SYSUTCDATETIME())			-- New order for Dan
UPDATE SalesOrder SET Product = 'Screw' WHERE SalesOrderId = 3			-- Changed product name for order 3 (Janice)
UPDATE SalesOrder SET SalesUserId = 2 WHERE SalesUserId = 3 AND Qty > 3	-- Reassign Dan's orders with Qty > 3 (orders 5 & 6) to Janice
DELETE SalesOrder WHERE SalesOrderId = 2								-- Delete order 2 (Janice)
SELECT * FROM SalesOrderView
REVERT

EXECUTE AS USER = 'jgalvin'
SELECT * FROM SalesOrderView	-- 2 is gone, 3 is changed, 5 & 6 were transfered from SalesUser2 
SELECT COUNT(*) FROM SalesOrder
REVERT

EXECUTE AS USER = 'dmu'
SELECT * FROM SalesOrderView	-- 7 is added, 5 & 6 were transferred to SalesUser1
SELECT COUNT(*) FROM SalesOrder
REVERT

-- Can toggle the security policy off (stop filtering)...
GO
ALTER SECURITY POLICY sec.SalesOrderPolicy WITH (STATE = OFF)
SELECT * FROM SalesOrderView

-- ...and on (start filtering)
GO
ALTER SECURITY POLICY sec.SalesOrderPolicy WITH (STATE = ON)
SELECT * FROM SalesOrderView


/* LAB */
-- Row-Level Security (RLS), part 2

/* STEP */
-- Cleanup from part 1

USE HolDb
GO

-- Drop the old security policy
SELECT * FROM SalesOrderView
DROP SECURITY POLICY sec.SalesOrderPolicy
SELECT * FROM SalesOrderView
GO

-- Drop sales users and it's role
DROP USER jadams
DROP USER jgalvin
DROP USER dmu
DROP USER jsmith
DROP USER djones
DROP ROLE SalesUsers

SELECT * FROM UsersView ORDER BY Username, ObjectName, PermissionName

/* STEP */
-- Assign passwords and grant permissions

-- Refactor SalesUser table to contain passwords for application-level authentication
ALTER TABLE dbo.SalesUser
	ADD Password varchar(50)
GO

UPDATE SalesUser SET Password = CASE Username
	WHEN 'jadams'	THEN 'ja_p@$$w0rd'
	WHEN 'jgalvin'	THEN 'jg_p@$$w0rd'
	WHEN 'dmu'		THEN 'dm_p@$$w0rd'
	WHEN 'jsmith'	THEN 'js_p@$$w0rd'
	WHEN 'djones'	THEN 'dj_p@$$w0rd'
	END

SELECT * FROM SalesUser

-- Create the single database user shared by all users of the application
CREATE USER AppUser WITH PASSWORD = 'app_p@$$w0rd'
GO

-- Grant full access on the table to any AppUser
GRANT SELECT, INSERT, UPDATE, DELETE ON SalesUser TO AppUser
GRANT SELECT, INSERT, UPDATE, DELETE ON SalesOrder TO AppUser
GRANT SELECT ON SalesOrderView TO AppUser

-- Also expose unmasked data to all authenticated application users
GRANT UNMASK TO AppUser

SELECT * FROM UsersView ORDER BY Username, ObjectName, PermissionName
GO

/* STEP */
-- Create predicate function

ALTER FUNCTION sec.SalesOrderPredicate(@SalesUserId AS int)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN
		SELECT
			1 AS result
		WHERE
			DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID('AppUser') AND (
				CONVERT(varchar, SESSION_CONTEXT(N'AppUsername')) = (SELECT Username FROM dbo.SalesUser WHERE SalesUserId = @SalesUserId) OR
				CONVERT(varchar, SESSION_CONTEXT(N'AppUsername')) = 'jadams')
GO

/* STEP */
-- Create security policy

CREATE SECURITY POLICY sec.SalesOrderPolicy
    ADD FILTER PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder,
    ADD BLOCK PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder AFTER INSERT,
    ADD BLOCK PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder AFTER UPDATE
    WITH (STATE = ON)

/* STEP */
-- Test RLS by impersonation

SELECT * FROM SalesOrderView
SELECT COUNT(*) FROM SalesOrder

EXECUTE AS USER = 'AppUser'
SELECT * FROM SalesOrderView
SELECT COUNT(*) FROM SalesOrder

-- As AppUser with AppUsername 'jgalvin', we get just the rows we own
EXEC sp_set_session_context @key = 'AppUsername', @value = 'jgalvin'
SELECT * FROM SalesOrderView
SELECT * FROM SalesOrder
SELECT COUNT(*) FROM SalesOrder
GO

-- Dan can see his own rows but not rows belonging to other users
EXEC sp_set_session_context @key = 'AppUsername', @value = 'dmu'
SELECT * FROM SalesOrderView
SELECT COUNT(*) FROM SalesOrder
GO

-- Dan can insert new rows for himself...
INSERT INTO SalesOrder VALUES (3, 11, 'Seat', 12, SYSUTCDATETIME())
SELECT * FROM SalesOrderView
SELECT COUNT(*) FROM SalesOrder

-- ...but he can't insert new rows for other users...
IF 0 = 1 BEGIN
	INSERT INTO SalesOrder VALUES (2, 11, 'Table', 8, SYSUTCDATETIME())
END

-- ...and he can't transfer rows we own to other users
IF 0 = 1 BEGIN
	UPDATE SalesOrder SET SalesUserId = 2 WHERE SalesOrderId = 4
END

-- As Jay the manager, RLS is effectively bypassed by the logic in the predicate function
EXEC sp_set_session_context @key = 'AppUsername', @value = 'jadams', @read_only = 1

-- Jay the manager can see all rows...
SELECT * FROM SalesOrderView
SELECT COUNT(*) FROM SalesOrder

-- ...and he can insert new rows for any other user...
INSERT INTO SalesOrder VALUES (2, 8, 'Table', 2, SYSUTCDATETIME())
INSERT INTO SalesOrder VALUES (3, 9, 'Lamp', 4, SYSUTCDATETIME())

-- ...and he can transfer rows from across users
UPDATE SalesOrder SET SalesUserId = 2 WHERE SalesOrderId = 4

-- View the changes
SELECT * FROM SalesOrderView

-- AppUsername in session context cannot be changed because it was set with the read_only option
IF 0 = 1 BEGIN
	EXEC sp_set_session_context @key = 'AppUsername', @value = 'jgalvin'
END

REVERT
GO

/* STEP */
-- Using RLS with a client app

-- Stored proc for client app to get sales orders with RLS applied
CREATE PROCEDURE SelectOrders
 AS
BEGIN
	SELECT * FROM SalesOrderView
END
GO

GRANT EXECUTE ON SelectOrders TO AppUser
GO

/* STEP */
-- Create client app
/*

// Program.cs
using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				if (!HolApp.Login())
				{
					Console.WriteLine("Authentication failed");
				}
				else
				{
					HolApp.Session();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			Console.WriteLine();
			Console.WriteLine("Press any key to continue");
			Console.ReadKey();
			return;
		}

	}
}

// HolApp.cs
using System;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApp1
{
	public static class HolApp
	{
		private const string ConnStr = "data source=.;initial catalog=HolDb;uid=AppUser;pwd=app_p@$$w0rd";
		private static int? _userId;
		private static string _username;
		private static string _email;

		internal static string Username => _username;

		public static bool Login()
		{
			Console.Clear();
			Console.WriteLine("Please login");
			Console.WriteLine();

			Console.Write("Username: ");
			var username = Console.ReadLine();

			Console.Write("Password: ");
			var password = Console.ReadLine();

			Console.WriteLine();

			using (var conn = OpenSqlConnection())
			{
				using (var cmd = conn.CreateCommand())
				{
					cmd.CommandText = "SELECT SalesUserId, Email FROM SalesUser WHERE Username = @Username AND Password = @Password";
					// note... cmd.Parameters.AddWithValue will *not* work for AE
					cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.VarChar, 50) { Value = username });
					cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50) { Value = password });

					using (var rdr = cmd.ExecuteReader())
					{
						if (!rdr.Read())
						{
							return false;
						}
						_username = username;
						_userId = (int)rdr["SalesUserId"];
						_email = rdr["Email"].ToString();
						rdr.Close();
					}
				}
			}

			return true;
		}

		public static void Session()
		{
			Console.WriteLine($"Welcome, {_username} (user ID: {_userId}; email: {_email}");

			while (true)
			{
				Console.WriteLine();
				Console.WriteLine("*** Menu ***");
				Console.WriteLine();
				Console.WriteLine("1. Display orders (row level security)");
				Console.WriteLine("Q. Quit");
				Console.Write("Choice: ");

				var key = Console.ReadKey().KeyChar.ToString().ToUpper();
				switch (key)
				{
					case "1":
						DisplayOrders();
						break;

					case "Q":
						return;
				}

			}
		}

		private static void DisplayOrders()
		{
			Console.WriteLine();
			Console.WriteLine();
			Console.WriteLine("Order list:");

			using (var conn = OpenSqlConnection())
			{
				using (var cmd = conn.CreateCommand())
				{
					cmd.CommandText = "SelectOrders";
					cmd.CommandType = CommandType.StoredProcedure;
					using (var rdr = cmd.ExecuteReader())
					{
						var count = 0;
						while (rdr.Read())
						{
							count++;
							Console.WriteLine(" " +
								$"Order: {rdr["SalesOrderId"]}; " +
								$"User: {rdr["Username"]}; " +
								$"Employee: {rdr["EmployeeName"]}; " +
								$"Customer: {rdr["CustomerName"]}; " +
								$"Product: {rdr["Product"]}; " +
								$"Qty: {rdr["Qty"]}; "
							);
						}
						Console.WriteLine("Total orders: {0}", count);
					}
				}
				conn.Close();
			}
		}

		private static SqlConnection OpenSqlConnection()
		{
			var conn = new SqlConnection(ConnStr);
			conn.Open();

			if (_username == null)
			{
				// user is unauthenticated; return an ordinary open connection
				return conn;
			}

			// user is authenticated; set the session context on the open connection for RLS
			try
			{
				using (var cmd = new SqlCommand("sp_set_session_context", conn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.Parameters.AddWithValue("@key", "AppUsername");
					cmd.Parameters.AddWithValue("@value", _username);
					cmd.Parameters.AddWithValue("@read_only", 1);

					cmd.ExecuteNonQuery();
				}
			}
			catch (Exception)
			{
				conn.Close();
				conn.Dispose();
				throw;
			}

			return conn;
		}

	}
}
*/
/* >>> Run client app - Display Orders <<< */


/* LAB */
-- Always Encrypted

/* STEP */
-- Encrypt columns with SSMS wizard

USE HolDb
GO

-- View sensitive data, unencrypted
SELECT * FROM SalesUser

-- Run case-insensitive queries
SELECT * FROM SalesUser WHERE Email = 'jay.adams@corp.com'
SELECT * FROM SalesUser WHERE Email = 'JAY.ADAMS@CORP.COM'
SELECT * FROM SalesUser WHERE Password = 'ja_p@$$w0rd'
SELECT * FROM SalesUser WHERE Password = 'JA_P@$$W0RD'
SELECT * FROM SalesUser WHERE Password >= 'h'

/*
	There is a *bug* in the SSMS AE Wizard when there is a referenced object
	that participates in an RLS predicate (in this case, the SalesUser table
	is related to the SalesOrder table, which has an RLS predicate that
	references back to SalesUser).

	In this case, the wizard temporarily drops both the RLS policy and the RLS
	predicate before migrating the table data. After migrating, the wizard
	recreates them. However, when it recreates the predicate, it fails to
	include WITH SCHEMABINDING. As a result, when it recreates the policy,
	an exception is thrown because an RLS predicate must be a schema-bound
	table-valued function.

	Related, any columns masked with DDM lose their masking after migration,
	and DDM must be reapplied manually as well. Note that these problems do
	not occur when using the wizard to save a PowerShell script that executes
	later; it occurs only when using the wizard to execute immediately.
*/

-- *bug* the SSMS wizard fails to reapply schemabinding to RLS predicate function
DROP SECURITY POLICY sec.SalesOrderPolicy

/* >>> Run AE Wizard <<< */

/*
	Use Always Encrypted Wizard in SSMS to encrypt sensitive columns (Tasks, Encrypt Columns...)
		- SalesUser table
			- Email (randomized)
			- Password (deterministic)

	The columns now look like this:

		Email varchar(100)
			COLLATE Latin1_General_BIN2
			ENCRYPTED WITH (
				COLUMN_ENCRYPTION_KEY = CEK_Auto1,
				ALGORITHM = N'AEAD_AES_256_CBC_HMAC_SHA_256',
				ENCRYPTION_TYPE = RANDOMIZED)

		Password varchar(50)
			COLLATE Latin1_General_BIN2
			ENCRYPTED WITH (
				COLUMN_ENCRYPTION_KEY = CEK_Auto1,
				ALGORITHM = N'AEAD_AES_256_CBC_HMAC_SHA_256',
				ENCRYPTION_TYPE = DETERMINISTIC)
*/

GO
-- *bug* reapply DDM to table
ALTER TABLE SalesUser
 ALTER COLUMN DateOfBirth
 ADD MASKED WITH (FUNCTION='default()')

GO
-- *bug* reapply schemabinding to RLS predicate function
ALTER FUNCTION sec.SalesOrderPredicate(@SalesUserId AS int)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN
		SELECT
			1 AS result
		WHERE
			DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID('AppUser') AND (
				CONVERT(varchar, SESSION_CONTEXT(N'AppUsername')) = (SELECT Username FROM dbo.SalesUser WHERE SalesUserId = @SalesUserId) OR
				CONVERT(varchar, SESSION_CONTEXT(N'AppUsername')) = 'jadams')
GO
-- *bug* recreate the RLS security policy
CREATE SECURITY POLICY sec.SalesOrderPolicy
    ADD FILTER PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder,
    ADD BLOCK PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder AFTER INSERT,
    ADD BLOCK PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder AFTER UPDATE
    WITH (STATE = ON)

-- Data appears encrypted
SELECT * FROM SalesUser

-- Can't run queries on encrypted columns
IF 0 = 1 BEGIN
	SELECT * FROM SalesUser WHERE Email = 'jay.adams@corp.com'
	SELECT * FROM SalesUser WHERE Password = 'ja_p@$$w0rd'
END

/* STEP */
-- View encryption keys

-- Discover Always Encrypted keys
SELECT * FROM sys.column_master_keys
SELECT * FROM sys.column_encryption_keys 
SELECT * FROM sys.column_encryption_key_values

-- Discover columns protected by Always Encrypted
SELECT * FROM sys.columns WHERE column_encryption_key_id IS NOT NULL

--  ...friendlier output
SELECT
	[column] = c.name,
	c.column_encryption_key_id,
	cek = cek.name,
	column_encryption_key_database_name = ISNULL(c.column_encryption_key_database_name, DB_NAME()),
	encryption_type_desc,
	encryption_algorithm_name
FROM
	sys.columns AS c
	INNER JOIN sys.column_encryption_keys AS cek ON c.column_encryption_key_id = cek.column_encryption_key_id
WHERE
	c.column_encryption_key_id IS NOT NULL

/* STEP */
-- Change connection (add column encryption setting=enabled)

-- Data appears decrypted
SELECT * FROM SalesUser

-- Still can't run queries on encrypted columns, or insert/update encrypted columns, with SSMS alone. These
-- actions must be parameterized, and issued by an ADO.NET client with "column encryption setting=enabled"
IF 0 = 1 BEGIN
	SELECT * FROM SalesUser WHERE Email = 'jay.adams@corp.com'
	SELECT * FROM SalesUser WHERE Password = 'ja_p@$$w0rd'
	INSERT INTO SalesUser VALUES 
	 ('fbaggins', 'Frodo', 'Baggins', '718-336-2013', 'frodo.baggins@shire.net', DATEFROMPARTS(1229, 1, 25), 'fb_p@$$w0rd')
END

/* STEP */
-- Run client application, add new user
/*
namespace ConsoleApp1
{
	public static class HolApp
	{
		private const string ConnStr = "data source=.;initial catalog=HolDb;uid=AppUser;pwd=app_p@$$w0rd;column encryption setting=enabled";

		// ...

		public static void Session()
		{
			// ...
				Console.WriteLine("2. Add new sales user (always encrypted)");
			// ...
					case "2":
						AddNewSalesUser();
						break;
			// ...
		}

		private static void AddNewSalesUser()
		{
			Console.WriteLine();
			Console.WriteLine();

			using (var conn = OpenSqlConnection())
			{
				using (var cmd = conn.CreateCommand())
				{
					cmd.CommandText = "INSERT INTO SalesUser VALUES (@Username, @FirstName, @LastName, @Phone, @Email, @DateOfBirth, @Password)";

					cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.VarChar, 50) { Value = "fbaggins" });
					cmd.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.VarChar, 50) { Value = "Frodo" });
					cmd.Parameters.Add(new SqlParameter("@LastName", SqlDbType.VarChar, 50) { Value = "Baggins" });
					cmd.Parameters.Add(new SqlParameter("@Phone", SqlDbType.VarChar, 50) { Value = "718-336-2013" });
					cmd.Parameters.Add(new SqlParameter("@Email", SqlDbType.VarChar, 50) { Value = "frodo.baggins@shire.net" });
					cmd.Parameters.Add(new SqlParameter("@DateOfBirth", SqlDbType.Date) { Value = new DateTime(1229, 1, 25) });
					cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50) { Value = "fb_p@$$w0rd" });

					cmd.ExecuteNonQuery();
					Console.WriteLine("Created new user: {0}", cmd.Parameters["@Username"].Value);
					Console.WriteLine();
				}
			}
		}
	}
}
*/

/* STEP */
-- Show encrypted data generated by client

-- Show encrypted data generated by client (in clear text)
SELECT * FROM SalesUser

/* >>> Change connection - column encryption setting=disabled <<< */

-- Show encrypted data generated by client unreadable
SELECT * FROM SalesUser
GO

/* STEP */
-- Using stored procedures with Always Encrypted

CREATE TABLE ActivityLog (
	ActivityLogId int IDENTITY,
	SalesUserId int,
	ActivityName varchar(20),
	CreatedAt datetime2 CONSTRAINT DF_ActivityLog_CreatedAt DEFAULT SYSUTCDATETIME(),
	CONSTRAINT PK_ActivityLog PRIMARY KEY (ActivityLogId),
	CONSTRAINT FK_ActivityLog_SalesUser FOREIGN KEY (SalesUserId) REFERENCES SalesUser(SalesUserId)
)
GO

CREATE PROCEDURE InsertActivityLog
	@SalesUserId int,
	@ActivityName varchar(max)
 AS
BEGIN

	INSERT INTO ActivityLog(SalesUserId, ActivityName)
	 VALUES(@SalesUserId, @ActivityName)

END
GO

CREATE PROCEDURE LoginUser
	@Username varchar(max),
	@Password varchar(max)
 AS
BEGIN

	DECLARE @SalesUserId int
	DECLARE @Email varchar(max)

	SELECT
		@SalesUserId = SalesUserId,
		@Email = Email
	FROM
		SalesUser
	WHERE
		Username = @Username AND Password = @Password

	IF @@ROWCOUNT = 0 RETURN

	EXEC InsertActivityLog @SalesUserId, 'Login'

	SELECT
		SalesUserId = @SalesUserId,
		Email = @Email

END
GO

GRANT EXECUTE ON LoginUser TO AppUser
GO

CREATE PROCEDURE InsertSalesUser
	@Username varchar(max),
	@FirstName varchar(max),
	@LastName varchar(max),
	@Phone varchar(max),
	@Email varchar(100),		-- Parameters mapped to AE columns must match the table definition exactly
	@DateOfBirth date,
	@Password varchar(50)		-- Parameters mapped to AE columns must match the table definition exactly
 AS
BEGIN

	INSERT INTO SalesUser (
		Username,
		FirstName,
		LastName,
		Phone,
		Email,
		DateOfBirth,
		Password
	)
	VALUES (
		@Username,
		@FirstName,
		@LastName,
		@Phone,
		@Email,
		@DateOfBirth,
		@Password
	)

	SELECT SCOPE_IDENTITY()

	DECLARE @SalesUserId int
	SELECT @SalesUserId = SalesUserId FROM SalesUser WHERE Username = CONVERT(varchar, SESSION_CONTEXT(N'AppUsername'))

	EXEC InsertActivityLog @SalesUserId, 'InsertSalesUser'

END
GO

GRANT EXECUTE ON InsertSalesUser TO AppUser
GO

/* STEP */
-- Run client application, add new user
/*
namespace ConsoleApp1
{
	public static class HolApp
	{
		public static bool Login()
		{
			// ...
					cmd.CommandText = "LoginUser";
					cmd.CommandType = CommandType.StoredProcedure;
			// ...
		}

		private static void AddNewSalesUser()
		{
			// ...
					cmd.CommandText = "InsertSalesUser";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.VarChar, 50) { Value = "ggrey" });
					cmd.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.VarChar, 50) { Value = "Gandalf" });
					cmd.Parameters.Add(new SqlParameter("@LastName", SqlDbType.VarChar, 50) { Value = "Grey" });
					cmd.Parameters.Add(new SqlParameter("@Phone", SqlDbType.VarChar, 50) { Value = "000-000-1111" });
					cmd.Parameters.Add(new SqlParameter("@Email", SqlDbType.VarChar, 50) { Value = "gandalf.grey@wizards.org" });
					cmd.Parameters.Add(new SqlParameter("@DateOfBirth", SqlDbType.Date) { Value = new DateTime(815, 6, 10) });
					cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50) { Value = "gg_p@$$w0rd" });
			// ...
		}
	}
}
*/

/* STEP */
-- Show encrypted data generated by client

SELECT * FROM SalesUser
SELECT * FROM ActivityLog

/* LAB */
-- Temporal

/* STEP */
-- View unmasked and decrypted data

USE HolDb
GO

-- Impersonate user that doesn't have UNMASK permission
EXECUTE AS USER = 'dev2'
GO

-- Table has masked and encrypted columns
SELECT * FROM SalesUser

-- As dbo, has UNMASK permission
REVERT

/* >>> Change connection - column encryption setting=enabled <<< */

SELECT * FROM SalesUser

GO

/* STEP */
-- Enable temporal on the SalesUser table

-- Convert SalesUser to temporal table by adding required datetime2 column pair in PERIOD FOR SYSTEM_TIME
ALTER TABLE SalesUser ADD
    ValidFrom datetime2 GENERATED ALWAYS AS ROW START NOT NULL DEFAULT CAST('1900-01-01 00:00:00.0000000' AS datetime2),
    ValidTo   datetime2 GENERATED ALWAYS AS ROW END   NOT NULL DEFAULT CAST('9999-12-31 23:59:59.9999999' AS datetime2),
	PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo)
GO

-- Turn on temporal (table must have a PK and SYSTEM_TIME period)
ALTER TABLE SalesUser
    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.SalesUserHistory))
GO

GRANT INSERT, UPDATE, DELETE ON SalesUser TO dev2
GRANT SELECT ON SalesUserHistory TO dev2
EXECUTE AS USER = 'dev2'
GO

SELECT * FROM SalesUser
SELECT * FROM SalesUserHistory
REVERT

/* STEP */
-- Apply data changes over time

-- Update sales user ID #7 three times
UPDATE SalesUser SET LastName = 'White', DateOfBirth = DATEFROMPARTS(715, 6, 10) WHERE SalesUserId = 7
WAITFOR DELAY '00:00:02'
UPDATE SalesUser SET Phone = '000-000-2222' WHERE SalesUserId = 7
WAITFOR DELAY '00:00:02'
UPDATE SalesUser SET Phone = '000-000-3333' WHERE SalesUserId = 7
WAITFOR DELAY '00:00:02'

-- Delete sales user ID #6
DELETE FROM SalesUser WHERE SalesUserId = 6

-- History table shows the changes (as dbo, without masking)
SELECT * FROM SalesUser
SELECT * FROM SalesUserHistory ORDER BY SalesUserId, ValidFrom

EXECUTE AS USER = 'dev2'
GO

-- History table shows the changes (as dev2, with masking)
SELECT * FROM SalesUser
SELECT * FROM SalesUserHistory ORDER BY SalesUserId, ValidFrom

REVERT
GO

-- *** Simulate longer time lapses ***

-- Drop RLS policy for related SalesOrder table
DROP SECURITY POLICY sec.SalesOrderPolicy

-- Drop RLS predicate for related SalesOrder table
DROP FUNCTION sec.SalesOrderPredicate

-- Disable temporal
ALTER TABLE SalesUser SET (SYSTEM_VERSIONING = OFF)
GO

-- First update was 35 days ago
UPDATE SalesUserHistory SET
	ValidTo = DATEADD(D, -35, ValidTo)
		WHERE LastName = 'Grey'

-- Second was 25 days ago
UPDATE SalesUserHistory SET
	ValidFrom = DATEADD(D, -35, ValidFrom),
	ValidTo = DATEADD(D, -25, ValidTo)
		WHERE LastName = 'White' AND Phone = '000-000-1111'

-- Third was just now
UPDATE SalesUserHistory SET
	ValidFrom = DATEADD(D, -25, ValidFrom)
		WHERE LastName = 'White' AND Phone = '000-000-2222'
 
-- Delete was 25 days ago
UPDATE SalesUserHistory SET
	ValidTo = DATEADD(D, -25, ValidTo)
		WHERE SalesUserId = 6

-- Re-enable temporal on SalesUser table
ALTER TABLE SalesUser SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.SalesUserHistory))
GO

-- Recreate RLS predicate for related SalesOrder table
CREATE FUNCTION sec.SalesOrderPredicate(@SalesUserId AS int)
    RETURNS TABLE
	WITH SCHEMABINDING
AS
    RETURN
		SELECT
			1 AS result
		WHERE
			DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID('AppUser') AND (
				CONVERT(varchar, SESSION_CONTEXT(N'AppUsername')) = (SELECT Username FROM dbo.SalesUser WHERE SalesUserId = @SalesUserId) OR
				CONVERT(varchar, SESSION_CONTEXT(N'AppUsername')) = 'jadams')
GO

-- Recreate RLS policy for related SalesOrder table
CREATE SECURITY POLICY sec.SalesOrderPolicy
    ADD FILTER PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder,
    ADD BLOCK PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder AFTER INSERT,
    ADD BLOCK PREDICATE sec.SalesOrderPredicate(SalesUserId) ON dbo.SalesOrder AFTER UPDATE
    WITH (STATE = ON)
GO
 
-- View the datetime changes
SELECT * FROM SalesUser
SELECT * FROM SalesUserHistory ORDER BY SalesUserId, ValidFrom
GO

/* STEP */
-- Run point-in-time queries

-- See how the data changed over time
DECLARE @FiveMinutesAgo datetime2 = DATEADD(s, -300, SYSUTCDATETIME())
DECLARE @ThirtyDaysAgo datetime2 = DATEADD(d, -30, SYSUTCDATETIME())
DECLARE @FourtyDaysAgo datetime2 = DATEADD(d, -40, SYSUTCDATETIME())
																					-- as of		#7											#6
																					-- ------------	-------------------------------------------	---------
SELECT * FROM SalesUser ORDER BY SalesUserId										-- now			Gandalf White	6/10/0715	000-000-3333	Deleted
SELECT * FROM SalesUser FOR SYSTEM_TIME AS OF @FiveMinutesAgo ORDER BY SalesUserId	-- 5 min ago	Gandalf White	6/10/0715	000-000-2222	Deleted
SELECT * FROM SalesUser FOR SYSTEM_TIME AS OF @ThirtyDaysAgo ORDER BY SalesUserId	-- 30 days ago	Gandalf White	6/10/0715	000-000-1111	Exists
SELECT * FROM SalesUser FOR SYSTEM_TIME AS OF @FourtyDaysAgo ORDER BY SalesUserId	-- 40 days ago	Gandalf Gray	6/10/0815	000-000-1111	Exists


/* LAB */
-- Stretch

/* STEP */
-- Generate test data

USE HolDb
GO

SELECT * FROM ActivityLog ORDER BY ActivityLogId
GO

-- Simulate 10 more activity log entries
GO
UPDATE ActivityLog SET CreatedAt = DATEADD(mm, -4, CreatedAt)
DECLARE @Count int = 10
DECLARE @CreatedAt datetime2 = DATEADD(dd, -1 * (@Count + 100), SYSUTCDATETIME())
DECLARE @Counter int = 0
WHILE @Counter < @Count BEGIN
	SET @Counter += 1
	SET @CreatedAt = DATEADD(dd, 1, @CreatedAt)
	DECLARE @Rnd1 int = RAND() * 10
	DECLARE @Rnd2 int = RAND() * 10
	DECLARE @ActivityName varchar(max) = CASE WHEN @Rnd1 < 5 THEN 'Login' ELSE 'InsertSalesUser' END
	DECLARE @SalesUserId int = CASE WHEN @Rnd2 < 4 THEN 2 WHEN @Rnd2 < 8 THEN 3 ELSE 4 END
	INSERT INTO ActivityLog (SalesUserId, ActivityName, CreatedAt) VALUES (@SalesUserId, @ActivityName, @CreatedAt)
END
GO

SELECT * FROM ActivityLog ORDER BY ActivityLogId

/* STEP */
-- Enable stretch on the local server

-- Configure the local server to enable stretch
EXEC sp_configure 'remote data archive', 1
RECONFIGURE 

/* STEP */
-- Enable stretch on the local database

-- Create master key
CREATE MASTER KEY
 ENCRYPTION BY PASSWORD = 'Hrd2GessP@ssw0rd!'

-- Create credential for communication between local and Azure servers (uses master key for encryption)
CREATE DATABASE SCOPED CREDENTIAL MyAzureServerCredentials
    WITH IDENTITY = 'saz' , SECRET = 'Big$ecret1'

-- Alter the local database to enable stretch (~ 3 min)
ALTER DATABASE HolDb
    SET REMOTE_DATA_ARCHIVE = ON (
        SERVER = 'lennidemo.database.windows.net',
        CREDENTIAL = MyAzureServerCredentials)

-- Discover databases enabled for stretch
SELECT name, is_remote_data_archive_enabled FROM sys.databases

-- Discover cloud databases being used for stretch
SELECT * FROM sys.remote_data_archive_databases

-- *** view remote database - has no tables yet ***

/* STEP */
-- Enable stretch on the local table

-- Fails because DEFAULT constraint is not supported
IF 0 = 1 BEGIN
	ALTER TABLE ActivityLog
		SET (REMOTE_DATA_ARCHIVE = ON (MIGRATION_STATE = PAUSED))
END

-- Remove DEFAULT constraint from CreatedAt column
ALTER TABLE ActivityLog DROP CONSTRAINT DF_ActivityLog_CreatedAt
GO

-- Update sproc that inserts into ActivityLog to supply explicit value for CreatedAt
ALTER PROCEDURE InsertActivityLog
	@SalesUserId int,
	@ActivityName varchar(max)
 AS
BEGIN
	INSERT INTO ActivityLog(SalesUserId, ActivityName, CreatedAt)
	 VALUES(@SalesUserId, @ActivityName, SYSUTCDATETIME())
END
GO

-- Enable stretch, but don't start migration
ALTER TABLE ActivityLog
	SET (REMOTE_DATA_ARCHIVE = ON (MIGRATION_STATE = PAUSED))

-- Discover tables enabled for stretch
SELECT name, is_remote_data_archive_enabled FROM sys.tables

-- Monitor migration status
SELECT * FROM sys.dm_db_rda_migration_status WHERE migrated_rows > 0
EXEC sp_spaceused @objname = 'dbo.ActivityLog'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'LOCAL_ONLY'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'REMOTE_ONLY'

/* STEP */
-- Start migration

ALTER TABLE ActivityLog
	SET (REMOTE_DATA_ARCHIVE = ON (MIGRATION_STATE = OUTBOUND))

SELECT * FROM sys.dm_db_rda_migration_status WHERE migrated_rows > 0
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'LOCAL_ONLY'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'REMOTE_ONLY'

SELECT * FROM ActivityLog ORDER BY ActivityLogId

-- *** view remote data ***

/* STEP */
-- Migrate more data

-- Simulate 100 more activity log entries
DECLARE @Count int = 100
DECLARE @CreatedAt datetime2 = DATEADD(dd, -1 * (@Count + 1), SYSUTCDATETIME())
DECLARE @Counter int = 0
WHILE @Counter < @Count BEGIN
	SET @Counter += 1
	SET @CreatedAt = DATEADD(dd, 1, @CreatedAt)
	DECLARE @Rnd1 int = RAND() * 10
	DECLARE @Rnd2 int = RAND() * 10
	DECLARE @ActivityName varchar(max) = CASE WHEN @Rnd1 < 8 THEN 'Login' ELSE 'InsertSalesUser' END
	DECLARE @SalesUserId int = CASE WHEN @Rnd2 < 4 THEN 2 WHEN @Rnd2 < 8 THEN 3 ELSE 4 END
	INSERT INTO ActivityLog (SalesUserId, ActivityName, CreatedAt) VALUES (@SalesUserId, @ActivityName, @CreatedAt)
END

SELECT * FROM ActivityLog ORDER BY ActivityLogId

-- Monitor
SELECT * FROM sys.dm_db_rda_migration_status WHERE migrated_rows > 0
EXEC sp_spaceused @objname = 'dbo.ActivityLog'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'LOCAL_ONLY'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'REMOTE_ONLY'

-- *** view remote data ***

-- Can't UPDATE/DELETE
/*
DELETE FROM ActivityLog WHERE ActivityLogId = 2
UPDATE ActivityLog SET ActivityName = 'Logout' WHERE ActivityLogId = 3
*/

/* STEP */
-- Unmigrate and disable stretch

-- Unmigrate before disabling
ALTER TABLE ActivityLog
	SET (REMOTE_DATA_ARCHIVE = ON (MIGRATION_STATE = INBOUND))

SELECT * FROM sys.dm_db_rda_migration_status WHERE migrated_rows > 0
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'LOCAL_ONLY'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'REMOTE_ONLY'

SELECT * FROM ActivityLog ORDER BY ActivityLogId

-- Disable stretch on the table
ALTER TABLE ActivityLog
	SET (REMOTE_DATA_ARCHIVE = OFF (MIGRATION_STATE = PAUSED))

-- *** delete remote table ***

/* STEP */
-- Partially stretch table

-- Add "IsOld" for partially stretched table
ALTER TABLE ActivityLog
 ADD IsOld bit
GO

UPDATE ActivityLog SET IsOld = 0
GO

-- Update sproc that inserts into ActivityLog to supply explicit value for IsOld
ALTER PROCEDURE InsertActivityLog
	@SalesUserId int,
	@ActivityName varchar(max)
 AS
BEGIN
	INSERT INTO ActivityLog(SalesUserId, ActivityName, CreatedAt, IsOld)
	 VALUES(@SalesUserId, @ActivityName, SYSUTCDATETIME(), 0)
END
GO

SELECT * FROM ActivityLog ORDER BY ActivityLogId
GO

-- Create filter predicate
CREATE FUNCTION dbo.ActivityLogStretchPredicate(@IsOld bit)
RETURNS TABLE
WITH SCHEMABINDING 
AS 
RETURN
	SELECT 1 AS is_eligible
	 WHERE @IsOld = 1
GO

-- Enable stretch with filter predicate
ALTER TABLE ActivityLog
	SET (REMOTE_DATA_ARCHIVE = ON (
		FILTER_PREDICATE = dbo.ActivityLogStretchPredicate(IsOld),
		MIGRATION_STATE = OUTBOUND))
GO

-- Mark 2 "cold" rows (must wait a bit for the remote part to get created before running UPDATE)
UPDATE ActivityLog
 SET IsOld = 1 WHERE ActivityLogId IN (1, 3)

SELECT * FROM sys.dm_db_rda_migration_status WHERE migrated_rows > 0
EXEC sp_spaceused @objname = 'dbo.ActivityLog'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'LOCAL_ONLY'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'REMOTE_ONLY'

SELECT * FROM ActivityLog ORDER BY ActivityLogId

-- *** view remote data ***

-- View activity log rows more than a month old
SELECT * FROM ActivityLog 
 WHERE CreatedAt < DATEADD(mm, -1, SYSUTCDATETIME())
 ORDER BY ActivityLogId

-- Stretch activity log rows more than a month old (must be sure not to update rows already stretched)
UPDATE ActivityLog
 SET IsOld = 1
 WHERE IsOld = 0 AND CreatedAt < DATEADD(mm, -1, SYSUTCDATETIME())

SELECT * FROM sys.dm_db_rda_migration_status WHERE migrated_rows > 0
EXEC sp_spaceused @objname = 'dbo.ActivityLog'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'LOCAL_ONLY'
EXEC sp_spaceused @objname = 'dbo.ActivityLog', @mode = 'REMOTE_ONLY'

SELECT * FROM ActivityLog ORDER BY ActivityLogId

-- SQL Server knows when it needs to run a remote database query and when it doesn't
SELECT * FROM ActivityLog WHERE ActivityName = 'Login' ORDER BY ActivityLogId
SELECT * FROM ActivityLog WHERE ActivityName = 'Login' AND IsOld = 0 ORDER BY ActivityLogId

-- Can't reverse the status once migrated
/*
UPDATE ActivityLog
 SET IsOld = 0 WHERE ActivityLogId = 3
*/

/* STEP */
-- Disable stretch without recovery

-- Disable stretch on the table without inbounding (lose stretched data)
ALTER TABLE ActivityLog
	SET (REMOTE_DATA_ARCHIVE = OFF_WITHOUT_DATA_RECOVERY (MIGRATION_STATE = PAUSED))

SELECT * FROM ActivityLog ORDER BY ActivityLogId

DROP FUNCTION ActivityLogStretchPredicate

-- Disable stretch on the database
ALTER DATABASE HolDb SET REMOTE_DATA_ARCHIVE = OFF
EXEC sp_configure 'remote data archive', 0
RECONFIGURE 
GO

DROP DATABASE SCOPED CREDENTIAL MyAzureServerCredentials
DROP MASTER KEY
GO

-- DROP remote database

/* LAB */
-- JSON

/* STEP */
-- Generate test data

USE HolDb
GO

-- Disable RLS on the SalesOrder table for the JSON demos
ALTER SECURITY POLICY sec.SalesOrderPolicy WITH (STATE = OFF)
GO

-- Add some more orders, so that customers 1, 2, and 3 each have 3 orders
INSERT INTO SalesOrder (SalesUserId, CustomerId, Product, Qty) VALUES
 (1, 1, 'Bracket', 8),	-- Ken
 (2, 1, 'Valve', 4),	-- Ken
 (3, 1, 'Screw', 10),	-- Ken
 (1, 2, 'Table', 1),	-- Terri
 (2, 2, 'Lamp', 6),		-- Terri
 (3, 3, 'Seat', 11),	-- Gail
 (1, 3, NULL, 3),		-- Gail (with NULL product)
 (2, 3, 'Lamp', 5)		-- Gail
GO

/* STEP */
-- Generating JSON with FOR JSON AUTO

/*** FOR JSON AUTO ***/

SELECT
	Customer.CustomerID,
	Customer.FirstName,
	Customer.LastName,
	SalesOrder.SalesOrderID,
	SalesOrder.Product,
	SalesOrder.Qty,
	SalesOrder.CreatedAt,
	SoldBy = CONCAT(SalesUser.FirstName, ' ', SalesUser.LastName)
FROM
	Customer
	INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
	INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
WHERE
	Customer.CustomerId BETWEEN 1 AND 3
--	Customer.CustomerId = 1
ORDER BY
	Customer.CustomerId,
	SalesOrder.SalesOrderId
-- FOR JSON AUTO
-- FOR JSON AUTO, INCLUDE_NULL_VALUES
-- FOR JSON AUTO, INCLUDE_NULL_VALUES, ROOT	-- ('TopThreeCustomers')
-- FOR JSON AUTO, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
-- FOR JSON AUTO, INCLUDE_NULL_VALUES, ROOT, WITHOUT_ARRAY_WRAPPER	-- Invalid; ROOT and WITHOUT_ARRAY_WRAPPER are mutually exclusive

/*** Composing JSON with variables ***/

DECLARE @FirstSet AS nvarchar(max)
DECLARE @SecondSet AS nvarchar(max)

SET @FirstSet =
(
	SELECT
		Customer.CustomerID,
		Customer.FirstName,
		Customer.LastName,
		SalesOrder.SalesOrderID,
		SalesOrder.Product,
		SalesOrder.Qty,
		SalesOrder.CreatedAt,
		SoldBy = CONCAT(SalesUser.FirstName, ' ', SalesUser.LastName)
	FROM
		Customer
		INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
		INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
	WHERE
		Customer.CustomerId IN (1, 2)
	ORDER BY
		Customer.CustomerId,
		SalesOrder.SalesOrderId
	FOR JSON AUTO, WITHOUT_ARRAY_WRAPPER
)

SET @SecondSet =
(
	SELECT
		Customer.CustomerID,
		Customer.FirstName,
		Customer.LastName,
		SalesOrder.SalesOrderID,
		SalesOrder.Product,
		SalesOrder.Qty,
		SalesOrder.CreatedAt,
		SoldBy = CONCAT(SalesUser.FirstName, ' ', SalesUser.LastName)
	FROM
		Customer
		INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
		INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
	WHERE
		Customer.CustomerId = 3
	ORDER BY
		Customer.CustomerId,
		SalesOrder.SalesOrderId
	FOR JSON AUTO, WITHOUT_ARRAY_WRAPPER
)

DECLARE @FinalJson AS nvarchar(max) = CONCAT(
	'{',
		'"BatchId": "', NEWID(), '",',
		'"Orders": [',
			@FirstSet, ', ', @SecondSet,
		']',
	'}'
)

SELECT @FinalJson
GO

/*** Nested FOR JSON queries ***/

-- Hybrid resultset (FOR JSON nested in another SELECT)
SELECT
	CustomerID,
	FirstName,
	LastName,
	SalesOrders = (
		SELECT TOP 100 PERCENT
			SalesOrderID,
			Product,
			Qty,
			CreatedAt,
			SoldBy = CONCAT(SalesUser.FirstName, ' ', SalesUser.LastName)
		FROM
			SalesOrder
			INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
		WHERE
			CustomerId = Customer.CustomerId
		ORDER BY
			SalesOrderId
		FOR JSON AUTO
	)
FROM
	Customer
WHERE
	Customer.CustomerId BETWEEN 1 AND 3
ORDER BY
	CustomerId

-- Can't use FOR JSON against Always-Encrypted columns in SalesUser
IF 0 = 1 BEGIN
	SELECT
		*
	FROM
		Customer
		INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
		INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
	WHERE
		Customer.CustomerId = 3
	FOR JSON AUTO, INCLUDE_NULL_VALUES
END

-- Works if Always Encrypted columns are excluded from FOR JSON query
SELECT
	Customer.*,
	SalesOrder.*,
	SalesUser.FirstName,
	SalesUser.LastName,
	SalesUser.Phone
FROM
	Customer
	INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
	INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
WHERE
	Customer.CustomerId = 3
FOR JSON AUTO, INCLUDE_NULL_VALUES

-- Of course, FOR JSON respects DDM
GRANT SELECT ON SalesOrder TO dev2
GO
EXECUTE AS USER = 'dev2'
GO

SELECT
	Customer.*,
	SalesOrder.*,
	SalesUser.FirstName,
	SalesUser.LastName,
	SalesUser.Phone
FROM
	Customer
	INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
	INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
WHERE
	Customer.CustomerId = 3
FOR JSON AUTO, INCLUDE_NULL_VALUES

REVERT
GO

/* STEP */
-- Generating JSON with FOR JSON PATH

/*** FOR JSON PATH ***/

-- Using PATH instead of AUTO completely flattens the resultset
SELECT
	Customer.CustomerID,
	Customer.FirstName,
	Customer.LastName,
	SalesOrder.SalesOrderID,
	SalesOrder.Product,
	SalesOrder.Qty,
	SalesOrder.CreatedAt,
	SoldBy = CONCAT(SalesUser.FirstName, ' ', SalesUser.LastName)
FROM
	Customer
	INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
	INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
WHERE
	Customer.CustomerId BETWEEN 1 AND 3
ORDER BY
	Customer.CustomerId,
	SalesOrder.SalesOrderId
FOR JSON AUTO
--FOR JSON PATH

-- FOR JSON PATH can introduce conflicting property names (e.g, CustomerId) when flattening the resultset
SELECT
	Customer.*,
	SalesOrder.*,
	SalesUser.FirstName,
	SalesUser.LastName,
	SalesUser.Phone
FROM
	Customer
	INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
	INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
WHERE
	Customer.CustomerId BETWEEN 1 AND 3
FOR JSON AUTO, INCLUDE_NULL_VALUES
--FOR JSON PATH, INCLUDE_NULL_VALUES


-- Completely flattened by FOR JSON PATH, conflicting column names resolved by aliasing
SELECT
	Customer.CustomerId,
	Customer.FirstName,
	Customer.LastName,
	Customer.Phone,
	Customer.Email,
	Customer.SocialSecurityNumber,
	Customer.Balance,
	SalesOrder.SalesOrderId,
	SalesOrder.SalesUserId,
	SalesOrder.CustomerId AS SalesOrderCustomerId,
	SalesOrder.Product,
	SalesOrder.Qty,
	SalesOrder.CreatedAt,
	SalesUser.FirstName AS SalesUserFirstName,
	SalesUser.LastName AS SalesUserLastName,
	SalesUser.Phone AS SalesUserPhone
FROM
	Customer
	INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
	INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
WHERE
	Customer.CustomerId BETWEEN 1 AND 3
FOR JSON PATH, INCLUDE_NULL_VALUES

-- Use dotted notation to customize shape, but the resultset is still flattened
SELECT
	Customer.CustomerId AS [Customer.Id],
	Customer.FirstName AS [Customer.Name.First],
	Customer.LastName AS [Customer.Name.Last],
	Customer.Phone AS [Customer.Phone],
	Customer.Email AS [Customer.Email],
	Customer.SocialSecurityNumber AS [Customer.Ssn],
	Customer.Balance AS [Customer.Balance],
	SalesOrder.SalesOrderId AS [Order.Id],
	SalesOrder.SalesUserId AS [Order.SalesUserId],
	SalesOrder.CustomerId AS [Order.CustomerId],
	SalesOrder.Product AS [Order.Product],
	SalesOrder.Qty AS [Order.Qty],
	SalesOrder.CreatedAt AS [Order.OrderDate],
	SalesUser.FirstName AS [Order.SalesUser.First],
	SalesUser.LastName AS [Order.SalesUser.Last],
	SalesUser.Phone AS [Order.SalesUser.Phone]
FROM
	Customer
	INNER JOIN SalesOrder ON SalesOrder.CustomerId = Customer.CustomerId
	INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
WHERE
	Customer.CustomerId = 3
FOR JSON PATH, INCLUDE_NULL_VALUES

-- Use nested queries (subqueries) instead of JOIN syntax to maintain hierarchical shape
SELECT 
	Customer.CustomerId AS [customer.id],
	Customer.FirstName AS [customer.name.first],
	Customer.LastName AS [customer.name.last],
	Customer.Phone AS [customer.phone],
	Customer.Email AS [customer.email],
	Customer.SocialSecurityNumber AS [customer.ssn],
	Customer.Balance AS [customer.balance],
	(SELECT SalesOrder.SalesOrderId AS [id],
			SalesOrder.Product AS [productName],
			SalesOrder.Qty AS [quantity],
			SalesOrder.CreatedAt AS [date],
			SalesOrder.SalesUserId AS [emp.id],
			SalesUser.FirstName AS [emp.first],
			SalesUser.LastName AS [emp.last],
			SalesUser.Phone AS [emp.phone]
	  FROM SalesOrder INNER JOIN SalesUser ON SalesUser.SalesUserId = SalesOrder.SalesUserId
	  WHERE SalesOrder.CustomerId = Customer.CustomerId
	  FOR JSON PATH) AS [orders]
 FROM Customer 
 WHERE CustomerId BETWEEN 1 AND 2
 FOR JSON PATH

/* STEP */
-- Storing JSON

/*** ISJSON ***/

DECLARE @JsonDoc AS varchar(max) = '
	{
			"customer": {
				"name": {
					"first": "Gail",
					"last": "Erickson"
				},
				"phone": "212-555-0187",
				"email: "gerickson@outlook.com",
				"ssn": "981554877",
				"balance": 811.4100
			}
	}
'

SELECT ISJSON(@JsonDoc)	-- Returns false because of missing closing quote on email property
GO

/*** Store JSON orders data in a table ***/

DROP TABLE IF EXISTS JsonOrder

CREATE TABLE JsonOrder(
    JsonOrderId int IDENTITY,
    SalesUserId int,
	CustomerId int,
	JsonDoc varchar(max),
	CONSTRAINT PK_JsonOrder PRIMARY KEY (JsonOrderId),
	CONSTRAINT FK_JsonOrder_SalesUser FOREIGN KEY (SalesUserId) REFERENCES SalesUser(SalesUserId),
	CONSTRAINT FK_JsonOrder_Customer FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerId),
    CONSTRAINT CK_JsonOrder_JsonContent CHECK (ISJSON(JsonDoc) = 1)
)

DECLARE @JsonDoc AS nvarchar(max) = N'
	{
		"productName: "Lamp",
		"quantity": 3,
		"price": 584.20,
		"date": "2017-04-16T23:36:31.5577236"
	}
'

INSERT INTO JsonOrder VALUES (1, 1, @JsonDoc)	-- Fails because of missing closing quote on productName property

SELECT * FROM JsonOrder

INSERT INTO JsonOrder VALUES (1, 1, '
	{
		"category": "Furniture",
		"details": {
			"productName": "Lamp",
			"quantity": 3,
			"price": 584.20
		},
		"specialInstructions": "Do not break the lamps",
		"date": "2017-04-16T23:36:31.5577236"
	}
')

INSERT INTO JsonOrder VALUES (1, 2, '
	{
		"category": "Books",
		"title": "Programming SQL Server",
		"author": "Lenni Lobel",
		"price": {
			"amount": 49.99,
			"currency": "USD"
		},
		"tags": [
			"developer",
			"SQL Server"
		]
	}
')

INSERT INTO JsonOrder VALUES (1, 3, '
	{
		"category": "Books",
		"title": "Developing ADO .NET",
		"author": "Andrew Brust",
		"price": {
			"amount": 39.93,
			"currency": "USD"
		},
		"tags": [
			"developer",
			"database",
			".NET"
		]
	}
')

INSERT INTO JsonOrder VALUES (1, 4, '
	{
		"category": "Books",
		"title": "Windows Cluster Server",
		"author": "Stephen Forte",
		"price": {
			"amount": 59.99,
			"currency": "CAD"
		},
		"tags": [
			"windows",
			"cluster"
		]
	}
')

SELECT * FROM JsonOrder

/* STEP */
-- Querying JSON

/*** JSON_VALUE and JSON_QUERY ***/

SELECT *
 FROM JsonOrder
 WHERE JSON_VALUE(JsonDoc, '$.category') = 'Books'

ALTER TABLE JsonOrder
 ADD Category AS JSON_VALUE(JsonDoc, '$.category')

CREATE INDEX IX_JsonOrder_Category
 ON JsonOrder(Category)

SELECT *
 FROM JsonOrder
 WHERE JSON_VALUE(JsonDoc, '$.category') = 'Furniture'

SELECT
	JsonOrderId,
	JSON_VALUE(JsonDoc, '$.title') AS Title,
	JSON_VALUE(JsonDoc, '$.author') AS Author,
	JSON_VALUE(JsonDoc, '$.price.amount') AS PriceAmount,
	JSON_VALUE(JsonDoc, '$.price.currency') AS PriceCurrency,
	JSON_QUERY(JsonDoc, '$.tags') AS Tags
 FROM
	JsonOrder
 WHERE
	JSON_VALUE(JsonDoc, '$.category') = 'Books'
	AND CONVERT(varchar(max), JSON_QUERY(JsonDoc, '$.tags')) LIKE '%"developer"%'

/* STEP */
-- Shredding JSON with OPENJSON

/*** OPENJSON ***/

DECLARE @Chunk varchar(max) = '
[
	{
		"category": "Books",
		"title": "Programming SQL Server",
		"author": "Lenni Lobel",
		"price": {
			"amount": 49.99,
			"currency": "USD"
		},
		"tags": [
			"developer",
			"SQL Server"
		]
	},
	{
		"category": "Books",
		"title": "Developing ADO .NET",
		"author": "Andrew Brust",
		"price": {
			"amount": 39.93,
			"currency": "USD"
		},
		"tags": [
			"developer",
			"database",
			".NET"
		]
	},
	{
		"category": "Books",
		"title": "Windows Cluster Server",
		"author": "Stephen Forte",
		"price": {
			"amount": 59.99,
			"currency": "CAD"
		},
		"tags": [
			"windows",
			"cluster"
		]
	}
]
'

SELECT * FROM OPENJSON(@Chunk)

SELECT *
 FROM		OPENJSON(@Chunk, '$') AS b
 WHERE		JSON_VALUE(b.value, '$.price.currency') = 'USD'
 ORDER BY	JSON_VALUE(b.value, '$.author')
	
SELECT *
 FROM		OPENJSON(@Chunk, '$[0]')

--	0 = null
--	1 = string
--	2 = int
--	3 = bool
--	4 = array
--  5 = object
GO


/*** OPENJSON (parent/child example) ***/

-- Receive a new customer with multiple orders as a JSON object
-- Store as new customer row with multiple child order rows for sales user 1 (Jay Adams)
DECLARE @Chunk varchar(max) = '
{
	"customer": {
		"name": {
			"first": "Steven",
			"last": "Stills"
		},
		"phone": "440-221-4918",
		"email": "sstills@csny.com",
		"ssn": "2839666849",
		"balance": 120.8400
	},
	"orderDate": "2017-04-16T23:36:31.5577236",
	"orders": [
		{
			"order": {
				"productName": "Seat",
				"quantity": 11
			}
		},
		{
			"order": {
				"productName": "Table",
				"quantity": 3
			}
		},
		{
			"order": {
				"productName": "Lamp",
				"quantity": 5
			}
		}
	]
}
'

-- The customer values can be extracted directly from the JSON source
INSERT INTO
	Customer
SELECT
	FirstName				= CONVERT(varchar(max),	JSON_VALUE(@Chunk, '$.customer.name.first')),
	LastName				= CONVERT(varchar(max),	JSON_VALUE(@Chunk, '$.customer.name.last')),
	Phone					= CONVERT(varchar(max),	JSON_VALUE(@Chunk, '$.customer.phone')),
	Email					= CONVERT(varchar(max),	JSON_VALUE(@Chunk, '$.customer.email')),
	SocialSecurityNumber	= CONVERT(varchar(max),	JSON_VALUE(@Chunk, '$.customer.ssn')),
	Balance					= CONVERT(money,		JSON_VALUE(@Chunk, '$.customer.balance'))

-- Get the new customer ID to use as FK for the orders
DECLARE @CustomerId int = SCOPE_IDENTITY()

-- Get the order date for all orders
DECLARE @CreatedAt datetime2 = JSON_VALUE(@Chunk, '$.orderDate')

-- To produce multiple child rows for each order, use OPENJSON to interate on $.orders
INSERT INTO
	SalesOrder
SELECT
	SalesUserId		= 1,	-- Jay Adams
	CustomerId		= @CustomerId,
	Product			= JSON_VALUE(c.value, '$.order.productName'),
	Qty				= JSON_VALUE(c.value, '$.order.quantity'),
	CreatedAt		= @CreatedAt
 FROM
	OPENJSON(@Chunk, '$.orders') AS c

SELECT * from Customer
SELECT * from SalesOrderView
GO

/*** OPENJSON (with schema) ***/

DECLARE @Chunk varchar(max) = '
{
	"customer": {
		"name": {
			"first": "Steven",
			"last": "Stills"
		},
		"phone": "440-221-4918",
		"email": "sstills@csny.com",
		"ssn": "2839666849",
		"balance": 120.8400
	},
	"orderDate": "2017-04-16T23:36:31.5577236",
	"orders": [
		{
			"order": {
				"productName": "Seat",
				"quantity": 11
			}
		},
		{
			"order": {
				"productName": "Table",
				"quantity": 3
			}
		},
		{
			"order": {
				"productName": "Lamp",
				"quantity": 5
			}
		}
	]
}
'

-- Query with default schema
SELECT *
 FROM OPENJSON (@Chunk, '$.orders')

SELECT
	Product	= CONVERT(varchar(max),	JSON_VALUE(value, '$.order.productName')),
	Qty		= CONVERT(int,			JSON_VALUE(value, '$.order.quantity'))
 FROM OPENJSON (@Chunk, '$.orders')
	
-- Query with explicit schema
SELECT *
 FROM OPENJSON (@Chunk, '$.orders')
 WITH ( 
	Product		varchar(max)	'$.order.productName',
	Qty			int				'$.order.quantity'
)

/* LAB */
-- FILESTREAM

/* STEP */
-- Enable FILESTREAM on the server

USE HolDb
GO

EXEC sp_configure filestream_access_level, 2  
RECONFIGURE  

/* STEP */
-- Enable FILESTREAM on the database

-- Show the database filegroups
SELECT * FROM sys.filegroups

-- Add a FILESTREAM filegroup to the database
ALTER DATABASE HolDb
 ADD FILEGROUP FileStreamGroup1 CONTAINS FILESTREAM

-- Add a container to the FILESTREAM filegroup
ALTER DATABASE HolDb
 ADD FILE (
	NAME = HolDb_blobs, 
	FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\HolDb_blobs')
 TO FILEGROUP FileStreamGroup1

-- Show the database filegroups
SELECT * FROM sys.filegroups
GO

/* STEP */
-- Enable FILESTREAM on Customer table

--ALTER TABLE Customer SET (FILESTREAM_ON=FileStreamGroup1)
ALTER TABLE Customer
 ADD
	RowId uniqueidentifier NOT NULL ROWGUIDCOL UNIQUE DEFAULT NEWSEQUENTIALID(),
	Photo varbinary(max) FILESTREAM NULL

GO

/* STEP */
-- Add FILESTREAM data using T-SQL

-- Add customer row with a simple text BLOB using CAST
INSERT INTO Customer (FirstName, LastName, Photo)
 VALUES(
	'Bob',
	'Blob',
	CAST('BLOB' AS varbinary(max)))

-- Peek and poke at the underlying file system
SELECT
	CustomerId,
	FirstName,
	LastName,
	Photo,
	DATALENGTH(Photo) AS BlobSize,
	CAST(Photo AS varchar) AS BlobAsText
 FROM
	Customer
 WHERE
	FirstName = 'Bob'

/* STEP */
-- Delete FILESTREAM data

-- Delete row with BLOB in it
DELETE FROM Customer WHERE FirstName = 'Bob'
SELECT * FROM Customer

EXEC sp_filestream_force_garbage_collection 

ALTER DATABASE HolDb SET RECOVERY SIMPLE
BACKUP DATABASE HolDb TO DISK = 'HolDbFull.bak' 
EXEC sp_filestream_force_garbage_collection 

/* STEP */
-- Add FILESTREAM data using T-SQL with OPENROWSET

-- Add customer row with an external image file imported using OPENROWSET and SINGLE_BLOB
INSERT INTO Customer (FirstName, LastName, Photo)
 VALUES(
	'Bob',
	'Blob',
	(SELECT BulkColumn FROM OPENROWSET(BULK
	  'C:\Projects\SQL2016 HOL Workshop.VS2017\HolContent\Photos\BobBlob.png',
	  SINGLE_BLOB) AS x))

SELECT
	CustomerId,
	FirstName,
	LastName,
	Photo,
	DATALENGTH(Photo) AS BlobSize
 FROM
	Customer
 WHERE
	FirstName = 'Bob'
	
/* STEP */
-- Add FILESTREAM data for SueBlue.jpg using the streaming API (SqlFileStream)

SELECT
	CustomerId,
	FirstName,
	LastName,
	Photo,
	DATALENGTH(Photo) AS BlobSize
 FROM
	Customer
 WHERE
	FirstName IN ('Bob', 'Sue')
	 
/* LAB */
-- FileTable

/* STEP */
-- Enable FileTable

-- View database level directory name and transacted access settings
SELECT
	db = DB_NAME(database_id),
	directory_name,
	non_transacted_access_desc
 FROM
	sys.database_filestream_options
 ORDER BY
	db

-- Enable the database for FileTable
ALTER DATABASE HolDb
 SET FILESTREAM
  (DIRECTORY_NAME='HolDb',			-- Enable FileTable in this database
   NON_TRANSACTED_ACCESS=FULL)		-- Enable access via Windows share

-- Use a different folder name for the database
ALTER DATABASE HolDb
 SET FILESTREAM
  (DIRECTORY_NAME='HOL Database')

-- View database level directory name and transacted access settings
SELECT
	db = DB_NAME(database_id),
	directory_name,
	non_transacted_access_desc
 FROM
	sys.database_filestream_options
 ORDER BY
	db

/* STEP */
-- Create a FileTable

--  (directory name defaults to table name, name column collation defaults to database collation)
CREATE TABLE ProductImage AS FileTable

-- Override the default FileTable directory name
ALTER TABLE ProductImage SET (FILETABLE_DIRECTORY = 'Product Images')

-- Discover FileTables in the database
SELECT name, is_filetable FROM sys.tables

/* STEP */
-- View FileTable defaults and constraints

/* Show path_locator default constraint */

SELECT
    d.name,
	d.[definition]
 FROM 
    sys.all_columns AS c
    INNER JOIN sys.tables AS t ON c.[object_id] = t.[object_id]
	INNER JOIN sys.schemas AS s ON t.[schema_id] = s.[schema_id]
	INNER JOIN sys.default_constraints AS d ON c.default_object_id = d.[object_id]
 WHERE
	s.name = 'dbo' AND t.name = 'ProductImage' AND c.name = 'path_locator'
GO

SELECT
	OBJECT_NAME(parent_object_id) FileTableName,
	OBJECT_NAME([object_id]) AS ObjectName
 FROM
	sys.filetable_system_defined_objects

GO

SELECT FILETABLEROOTPATH('ProductImage')
SELECT GETPATHLOCATOR(FILETABLEROOTPATH('ProductImage'))
SELECT GETPATHLOCATOR(FILETABLEROOTPATH('ProductImage')).ToString()

SELECT FILETABLEROOTPATH('ProductImage') + '\Seat.jpg'
SELECT GETPATHLOCATOR(FILETABLEROOTPATH('ProductImage') + '\Seat.jpg')
SELECT GETPATHLOCATOR(FILETABLEROOTPATH('ProductImage') + '\Seat.jpg').ToString()

INSERT INTO ProductImage(name, file_stream)
 VALUES(
	'Seat.jpg',
	(SELECT BulkColumn FROM OPENROWSET(BULK 'C:\Projects\SQL2016 HOL Workshop.VS2017\HolContent\Photos\Seat.jpg', SINGLE_BLOB) AS x)
)
SELECT * FROM ProductImage

SELECT FILETABLEROOTPATH('ProductImage') + '\Seat.jpg'
SELECT GETPATHLOCATOR(FILETABLEROOTPATH('ProductImage') + '\Seat.jpg')
SELECT GETPATHLOCATOR(FILETABLEROOTPATH('ProductImage') + '\Seat.jpg').ToString()

SELECT
	name,
	is_directory,
	path_locator.ToString()
FROM
	ProductImage

/* LAB */
-- Geospatial

/* STEP */
-- Add customer location data
USE HolDb
GO

ALTER TABLE Customer
 ADD LocationGeo geography

UPDATE Customer SET LocationGeo = CHOOSE(CustomerId,
 ('POINT(-111.06687 45.01188)'),
 ('POINT(-104.06 41.01929)'),
 ('POINT(-111.05878 41.003)'),
 ('POINT(-121.05878 41.003)'),
 ('POINT(-110.05878 43.003)'),
 ('POINT(-113.05878 35.003)'),
 ('POINT(-116.05878 34.003)'),
 ('POINT(-114.05878 43.003)'))
WHERE CustomerId BETWEEN 1 AND 8

GO

SELECT * FROM Customer
GO

/* STEP */
-- Create stored procedure for WebAPI service

CREATE PROCEDURE GetCustomerLocations
AS
 BEGIN
	SELECT  FirstName, LastName, Phone, LocationGeo
     FROM   Customer
	 WHERE	LocationGeo IS NOT NULL
 END
GO

EXEC GetCustomerLocations

/* STEP */
-- Build WebAPI code
/*

// New Project, Web, ASP.NET Web Application, CustomerMappingApp
//  Empty, with Web API references

// CustomerGeoController.cs
using Microsoft.SqlServer.Types;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;

namespace CustomerMappingApp.Controllers
{
	public class Customer
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Phone { get; set; }
		public double Latitude { get; set; }
		public double Longitude { get; set; }
	}
	
	public class CustomerGeoController : ApiController
	{
		public IEnumerable<Customer> GetCustomers()
		{
			const string ConnStr = "Data Source=.;Initial Catalog=HolDb;Integrated Security=True;";

			var customers = new List<Customer>();

			using (var conn = new SqlConnection(ConnStr))
			{
				conn.Open();
				using (var cmd = new SqlCommand("GetCustomerLocations", conn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					using (var rdr = cmd.ExecuteReader())
					{
						while (rdr.Read())
						{
							var geo = SqlGeography.Deserialize(rdr.GetSqlBytes(3));
							var customer = new Customer()
							{
								FirstName = rdr.GetSqlString(0).Value,
								LastName = rdr.GetSqlString(1).Value,
								Phone = rdr.GetSqlString(2).Value,
								Latitude = geo.Lat.Value,
								Longitude = geo.Long.Value
							};
							customers.Add(customer);
						}
						rdr.Close();
					}
				}
				conn.Close();

				return customers;
			}

		}
    }
}
*/

/* STEP */
-- Build client mashup page
/*

// HomePage.html
<html>
<head>
	<title>Bing Maps Mashup</title>
</head>
<body>
	<script src="http://dev.virtualearth.net/mapcontrol/mapcontrol.ashx"></script>
	<button onclick="mapCustomers()" style="margin: 8px;">
		Get Customers
	</button>
	<div>
		<div id='divVirtualEarthMap' style="position: relative; width: 640px; height: 400px;" />
	</div>

	<script type="text/javascript">

		var _map = new VEMap('divVirtualEarthMap');
		_map.LoadMap();

		var _xhr = new XMLHttpRequest();

		function mapCustomers() {
			_xhr.open("GET", "/api/CustomerGeo", true);
			_xhr.onload = onDataRetrievalComplete;
			_xhr.send();
		}

		function onDataRetrievalComplete() {
			var results = JSON.parse(_xhr.responseText);
			for (i = 0; i < results.length; i++) {
				var point = new VELatLong(results[i].Latitude, results[i].Longitude);
				var pin = new VEShape(VEShapeType.Pushpin, point);
				pin.SetTitle(results[i].FirstName + " " + results[i].LastName);
				pin.SetDescription(results[i].Phone);
				_map.AddShape(pin);
			}
		}

	</script>
</body>
</html>

*/
