﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace HolContent
{
	public partial class MainForm : Form
	{
		private bool _isPublishMode;
		public MainForm()
		{
			InitializeComponent();
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			this._isPublishMode = ((Form.ModifierKeys & Keys.Shift) > 0);
			if (!this._isPublishMode)
			{
				this.BackupLabToolStripMenuItem.Visible = false;
			}

			this.PopulateNodes();
		}

		private void PopulateNodes()
		{
			var contentScript = File.ReadAllText("HolCode.sql");
			var labs = contentScript.Split(new[] { "/* LAB */" }, StringSplitOptions.None);
			var courseName = labs[0].StripTSqlCommentSyntax();
			this.Text = courseName;

			for (var i = 1; i < labs.Length; i++)
			{
				var lab = labs[i];
				var labLines = lab.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
				var labName = labLines[1].StripTSqlCommentSyntax();
				var labNode = this.ContentTreeView.Nodes.Add($"Lab {i}. {labName}");
				var labNodeTag = default(string);
				if (this._isPublishMode)
				{
					labNodeTag = $"/* Lab {i} */{lab}";
				}
				else
				{
					labNodeTag = $"/* Lab {i}. {labName} */";
				}
				labNode.Tag = labNodeTag;

				var steps = lab.Split(new[] { "/* STEP */" }, StringSplitOptions.None);
				if (steps.Length > 1)
				{
					for (var j = 1; j < steps.Length; j++)
					{
						var step = steps[j];
						var stepLines = step.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
						var stepName = stepLines[1].StripTSqlCommentSyntax();
						var stepNode = labNode.Nodes.Add($"Step {j}. {stepName}");
						stepNode.Tag = $"/* Lab {i}, Step {j} */\r\n-- {labName}{step}";
						stepNode.ForeColor = Color.RoyalBlue;
					}
				}
			}
		}

		private void ContentTreeView_AfterSelect(object sender, TreeViewEventArgs e)
		{
			this.ContentTextBox.Text = e.Node.Tag?.ToString();
		}

		private void CopyAllToolStripButton_Click(object sender, EventArgs e)
		{
			Clipboard.SetText(this.ContentTextBox.Text);
		}

		private void CopyToolStripButton_Click(object sender, EventArgs e)
		{
			if (this.ContentTextBox.SelectedText.Length > 0)
			{
				Clipboard.SetText(this.ContentTextBox.SelectedText);
			}
		}

		private void TreeCollapseAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.ContentTreeView.CollapseAll();
		}

		private void TreeExpandAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.ContentTreeView.ExpandAll();
			if (this.ContentTreeView.SelectedNode != null)
			{
				this.ContentTreeView.SelectedNode.EnsureVisible();
			}
		}

		private void ContentTreeView_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				this.ContentTreeView.SelectedNode = this.ContentTreeView.GetNodeAt(e.X, e.Y);
			}
		}

		private void BackupLabToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				var labNumber = this.GetLabNumber();

				if (MessageBox.Show($"Backup lab {labNumber}?", "Confirm Backup", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
				{
					return;
				}

				var sql = $@"
					BACKUP DATABASE HolDb TO DISK = 'HolDb-lab{labNumber}.bak'
				";

				this.RunSql(sql);
				MessageBox.Show($"Successfully backed up lab {labNumber}", "Backup", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void RestoreLabToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				var labNumber = this.GetLabNumber();

				if (MessageBox.Show($"Restore lab {labNumber}?", "Confirm Restore", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
				{
					return;
				}

				this.TryRunSql("ALTER DATABASE HolDb SET SINGLE_USER WITH ROLLBACK IMMEDIATE");
				this.RunSql("DROP DATABASE IF EXISTS HolDb");

				this.RunSql(new string[] {
					"EXEC sp_configure 'contained database authentication', 1",
					"EXEC sp_configure filestream_access_level, 2",
					"RECONFIGURE"
				});
				this.RunSql($"RESTORE DATABASE HolDb FROM DISK = 'HolDb-lab{labNumber}.bak'");

				MessageBox.Show($"Successfully restored lab {labNumber}", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void TryRunSql(string commandText)
		{
			try
			{
				this.RunSql(commandText);
			}
			catch { }
		}

		private void RunSql(string commandText)
		{
			this.RunSql(new string[] { commandText });
		}

		private void RunSql(IEnumerable<string> commandTexts)
		{
			const string ConnStr = "data source=.;initial catalog=master;integrated security=true;";
			using (var conn = new SqlConnection(ConnStr))
			{
				conn.Open();
				using (var cmd = conn.CreateCommand())
				{
					foreach (var commandText in commandTexts)
					{
						cmd.CommandText = commandText;
						cmd.ExecuteNonQuery();
					}
				}
			}
		}

		private int GetLabNumber()
		{
			var node = this.ContentTreeView.SelectedNode;
			while (true)
			{
				if (node == null)
				{
					throw new Exception("There is no selected lab. First select a lab, then try again.");
				}
				if (node.Text.StartsWith("Lab "))
				{
					return int.Parse(node.Text.Split('.')[0].Split(' ')[1]);
				}
				node = node.Parent;
			}
		}

		private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
		{
			var node = this.ContentTreeView.SelectedNode;
			if ((node == null) || (!node.Text.StartsWith("Lab ")))
			{
				e.Cancel = true;
			}
		}

	}

	public static class Extensions
	{
		public static string StripTSqlCommentSyntax(this string line)
		{
			if (line.StartsWith("--"))
			{
				line = line.Substring(2).TrimStart();
			}
			return line;
		}
	}

}
