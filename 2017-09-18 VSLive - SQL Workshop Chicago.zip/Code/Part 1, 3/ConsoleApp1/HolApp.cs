﻿#define USE_ENCRYPTION
#define USE_STORED_PROCS

using System;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApp1
{
	public static class HolApp
	{
#if !USE_ENCRYPTION
		private const string ConnStr = "data source=.;initial catalog=HolDb;uid=AppUser;pwd=app_p@$$w0rd";
#else
		private const string ConnStr = "data source=.;initial catalog=HolDb;uid=AppUser;pwd=app_p@$$w0rd;column encryption setting=enabled";
#endif
		private static int? _userId;
		private static string _username;
		private static string _email;

		internal static string Username => _username;

		public static bool Login()
		{
			Console.Clear();
			Console.WriteLine("Please login");
			Console.WriteLine();

			Console.Write("Username: ");
			var username = Console.ReadLine();

			Console.Write("Password: ");
			var password = Console.ReadLine();

			Console.WriteLine();

			using (var conn = OpenSqlConnection())
			{
				using (var cmd = conn.CreateCommand())
				{
#if !USE_STORED_PROCS
					cmd.CommandText = "SELECT SalesUserId, Email FROM SalesUser WHERE Username = @Username AND Password = @Password";
#else
					cmd.CommandText = "LoginUser";
					cmd.CommandType = CommandType.StoredProcedure;
#endif
					// note... cmd.Parameters.AddWithValue will *not* work for AE
					cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.VarChar, 50) { Value = username });
					cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50) { Value = password });

					using (var rdr = cmd.ExecuteReader())
					{
						if (!rdr.Read())
						{
							return false;
						}
						_username = username;
						_userId = (int)rdr["SalesUserId"];
						_email = rdr["Email"].ToString();
						rdr.Close();
					}
				}
			}

			return true;
		}

		public static void Session()
		{
			Console.WriteLine($"Welcome, {_username} (user ID: {_userId}; email: {_email}");

			while (true)
			{
				Console.WriteLine();
				Console.WriteLine("*** Menu ***");
				Console.WriteLine();
				Console.WriteLine("1. Display orders (row level security)");
#if USE_ENCRYPTION
				Console.WriteLine("2. Add new sales user (always encrypted)");
#endif
				Console.WriteLine("Q. Quit");
				Console.Write("Choice: ");

				var key = Console.ReadKey().KeyChar.ToString().ToUpper();
				switch (key)
				{
					case "1":
						DisplayOrders();
						break;

#if USE_ENCRYPTION
					case "2":
						AddNewSalesUser();
						break;
#endif

					case "Q":
						return;
				}

			}
		}

		private static void DisplayOrders()
		{
			Console.WriteLine();
			Console.WriteLine();
			Console.WriteLine("Order list:");

			using (var conn = OpenSqlConnection())
			{
				using (var cmd = conn.CreateCommand())
				{
					cmd.CommandText = "SelectOrders";
					cmd.CommandType = CommandType.StoredProcedure;
					using (var rdr = cmd.ExecuteReader())
					{
						var count = 0;
						while (rdr.Read())
						{
							count++;
							Console.WriteLine(" " +
								$"Order: {rdr["SalesOrderId"]}; " +
								$"User: {rdr["Username"]}; " +
								$"Employee: {rdr["EmployeeName"]}; " +
								$"Customer: {rdr["CustomerName"]}; " +
								$"Product: {rdr["Product"]}; " +
								$"Qty: {rdr["Qty"]}; "
							);
						}
						Console.WriteLine("Total orders: {0}", count);
					}
				}
				conn.Close();
			}
		}

#if USE_ENCRYPTION
		private static void AddNewSalesUser()
		{
			Console.WriteLine();
			Console.WriteLine();

			using (var conn = OpenSqlConnection())
			{
				using (var cmd = conn.CreateCommand())
				{
#if !USE_STORED_PROCS
					cmd.CommandText = "INSERT INTO SalesUser VALUES (@Username, @FirstName, @LastName, @Phone, @Email, @DateOfBirth, @Password)";

					cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.VarChar, 50) { Value = "fbaggins" });
					cmd.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.VarChar, 50) { Value = "Frodo" });
					cmd.Parameters.Add(new SqlParameter("@LastName", SqlDbType.VarChar, 50) { Value = "Baggins" });
					cmd.Parameters.Add(new SqlParameter("@Phone", SqlDbType.VarChar, 50) { Value = "718-336-2013" });
					cmd.Parameters.Add(new SqlParameter("@Email", SqlDbType.VarChar, 50) { Value = "frodo.baggins@shire.net" });
					cmd.Parameters.Add(new SqlParameter("@DateOfBirth", SqlDbType.Date) { Value = new DateTime(1229, 1, 25) });
					cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50) { Value = "fb_p@$$w0rd" });
#else
					cmd.CommandText = "InsertSalesUser";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.VarChar, 50) { Value = "ggrey" });
					cmd.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.VarChar, 50) { Value = "Gandalf" });
					cmd.Parameters.Add(new SqlParameter("@LastName", SqlDbType.VarChar, 50) { Value = "Grey" });
					cmd.Parameters.Add(new SqlParameter("@Phone", SqlDbType.VarChar, 50) { Value = "000-000-1111" });
					cmd.Parameters.Add(new SqlParameter("@Email", SqlDbType.VarChar, 50) { Value = "gandalf.grey@wizards.org" });
					cmd.Parameters.Add(new SqlParameter("@DateOfBirth", SqlDbType.Date) { Value = new DateTime(815, 6, 10) });
					cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50) { Value = "gg_p@$$w0rd" });
#endif
					cmd.ExecuteNonQuery();
					Console.WriteLine("Created new user: {0}", cmd.Parameters["@Username"].Value);
					Console.WriteLine();
				}
			}
		}
#endif

		private static SqlConnection OpenSqlConnection()
		{
			var conn = new SqlConnection(ConnStr);
			conn.Open();

			if (_username == null)
			{
				// user is unauthenticated; return an ordinary open connection
				return conn;
			}

			// user is authenticated; set the session context on the open connection for RLS
			try
			{
				using (var cmd = new SqlCommand("sp_set_session_context", conn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.Parameters.AddWithValue("@key", "AppUsername");
					cmd.Parameters.AddWithValue("@value", _username);
					cmd.Parameters.AddWithValue("@read_only", 1);

					cmd.ExecuteNonQuery();
				}
			}
			catch (Exception)
			{
				conn.Close();
				conn.Dispose();
				throw;
			}

			return conn;
		}

	}
}
