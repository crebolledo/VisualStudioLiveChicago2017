﻿using System;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				if (!HolApp.Login())
				{
					Console.WriteLine("Authentication failed");
				}
				else
				{
					HolApp.Session();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			Console.WriteLine();
			Console.WriteLine("Press any key to continue");
			Console.ReadKey();
			return;
		}

	}
}
