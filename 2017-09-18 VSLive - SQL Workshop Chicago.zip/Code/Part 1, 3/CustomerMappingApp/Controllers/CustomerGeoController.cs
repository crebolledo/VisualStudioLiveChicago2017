﻿using Microsoft.SqlServer.Types;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;

namespace CustomerMappingApp.Controllers
{
	public class Customer
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Phone { get; set; }
		public double Latitude { get; set; }
		public double Longitude { get; set; }
	}
	
	public class CustomerGeoController : ApiController
    {
		public IEnumerable<Customer> GetCustomers()
		{
			const string ConnStr = "Data Source=.;Initial Catalog=HolDb;Integrated Security=True;";

			var customers = new List<Customer>();

			using (var conn = new SqlConnection(ConnStr))
			{
				conn.Open();
				using (var cmd = new SqlCommand("GetCustomerLocations", conn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					using (var rdr = cmd.ExecuteReader())
					{
						while (rdr.Read())
						{
							var geo = SqlGeography.Deserialize(rdr.GetSqlBytes(3));
							var customer = new Customer()
							{
								FirstName = rdr.GetSqlString(0).Value,
								LastName = rdr.GetSqlString(1).Value,
								Phone = rdr.GetSqlString(2).Value,
								Latitude = geo.Lat.Value,
								Longitude = geo.Long.Value
							};
							customers.Add(customer);
						}
						rdr.Close();
					}
				}
				conn.Close();

				return customers;
			}

		}
    }
}
