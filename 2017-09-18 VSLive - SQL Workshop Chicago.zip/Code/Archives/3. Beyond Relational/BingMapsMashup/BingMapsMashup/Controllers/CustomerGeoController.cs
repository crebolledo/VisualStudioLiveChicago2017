﻿using Microsoft.SqlServer.Types;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;

namespace BingMapsMashup.Controllers
{
	public class Customer
	{
		public string Name { get; set; }
		public string Company { get; set; }
		public double Latitude { get; set; }
		public double Longitude { get; set; }
	}
	
	public class CustomerGeoController : ApiController
    {
		public IEnumerable<Customer> GetCustomers()
		{
			const string ConnStr = "Data Source=.;Initial Catalog=MyDb;Integrated Security=True;";

			var customers = new List<Customer>();

			using (var conn = new SqlConnection(ConnStr))
			{
				conn.Open();
				using (var cmd = new SqlCommand("GetCustomers", conn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					using (var rdr = cmd.ExecuteReader())
					{
						while (rdr.Read())
						{
							var customer = new Customer();

							customer.Name = rdr.GetSqlString(0).Value;
							customer.Company = rdr.GetSqlString(1).Value;
							var geo = SqlGeography.Deserialize(rdr.GetSqlBytes(2));
							customer.Latitude = geo.Lat.Value;
							customer.Longitude = geo.Long.Value;

							customers.Add(customer);
						}
						rdr.Close();
					}
				}
				conn.Close();

				return customers;
			}

		}
    }
}
