﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using Microsoft.SqlServer.Server;

namespace TVPsWithEF
{
  public class OrderTvp : List<Order>, IEnumerable<SqlDataRecord>
  {
    public OrderTvp(Order header)
    {
      this.Add(header);
    }

    IEnumerator<SqlDataRecord> IEnumerable<SqlDataRecord>.GetEnumerator()
    {
      var sdr = new SqlDataRecord(
        new SqlMetaData("CustomerId", SqlDbType.Int),
        new SqlMetaData("OrderedAt", SqlDbType.Date));

      foreach (Order o in this)
      {
        sdr.SetInt32(0, o.CustomerId);
        sdr.SetDateTime(1, o.OrderedAt);

        yield return sdr;
      }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      return base.GetEnumerator();
    }
  }
}
