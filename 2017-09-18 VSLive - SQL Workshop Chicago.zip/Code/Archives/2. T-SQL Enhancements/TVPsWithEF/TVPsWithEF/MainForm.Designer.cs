﻿namespace TVPsWithEF
{
  partial class MainForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.btnPlainEF = new System.Windows.Forms.Button();
      this.btnEFUsingTVPs = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // btnPlainEF
      // 
      this.btnPlainEF.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnPlainEF.Location = new System.Drawing.Point(12, 12);
      this.btnPlainEF.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.btnPlainEF.Name = "btnPlainEF";
      this.btnPlainEF.Size = new System.Drawing.Size(294, 66);
      this.btnPlainEF.TabIndex = 1;
      this.btnPlainEF.Text = "Normal EF Updates";
      this.btnPlainEF.UseVisualStyleBackColor = true;
      this.btnPlainEF.Click += new System.EventHandler(this.btnPlainEF_Click);
      // 
      // btnEFUsingTVPs
      // 
      this.btnEFUsingTVPs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnEFUsingTVPs.Location = new System.Drawing.Point(12, 92);
      this.btnEFUsingTVPs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.btnEFUsingTVPs.Name = "btnEFUsingTVPs";
      this.btnEFUsingTVPs.Size = new System.Drawing.Size(294, 66);
      this.btnEFUsingTVPs.TabIndex = 2;
      this.btnEFUsingTVPs.Text = "TVPs with Entity Framework";
      this.btnEFUsingTVPs.UseVisualStyleBackColor = true;
      this.btnEFUsingTVPs.Click += new System.EventHandler(this.btnEFUsingTVPs_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(319, 173);
      this.Controls.Add(this.btnEFUsingTVPs);
      this.Controls.Add(this.btnPlainEF);
      this.Name = "MainForm";
      this.Text = "Form1";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button btnPlainEF;
    private System.Windows.Forms.Button btnEFUsingTVPs;
  }
}

