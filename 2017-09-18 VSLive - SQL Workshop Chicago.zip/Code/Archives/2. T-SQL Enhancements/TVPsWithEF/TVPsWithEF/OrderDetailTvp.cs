﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using Microsoft.SqlServer.Server;

namespace TVPsWithEF
{
  public class OrderDetailTvp : IEnumerable<SqlDataRecord>
  {
    private List<OrderDetail> _innerList;

    public OrderDetailTvp(IEnumerable<OrderDetail> details)
    {
      this._innerList = new List<OrderDetail>();
      this._innerList.AddRange(details);
    }

    IEnumerator<SqlDataRecord> IEnumerable<SqlDataRecord>.GetEnumerator()
    {
      var sdr = new SqlDataRecord(
        new SqlMetaData("ProductId", SqlDbType.Int),
        new SqlMetaData("Quantity", SqlDbType.Int),
        new SqlMetaData("Price", SqlDbType.Money));

      foreach (OrderDetail od in this._innerList)
      {
        sdr.SetInt32(0, od.ProductId);
        sdr.SetInt32(1, od.Quantity);
        sdr.SetDecimal(2, od.Price);

        yield return sdr;
      }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      throw new InvalidOperationException();
    }

    public OrderDetail this[int i]
    {
      get
      {
        return this._innerList[i];
      }
    }

  }
}
