﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TVPsWithEF
{
  public partial class MainForm : Form
  {
    public MainForm()
    {
      InitializeComponent();
    }

    private void btnPlainEF_Click(object sender, EventArgs e)
    {
      // Create an Order entity with child OrderDetail entities
      var order = new Order() { CustomerId = 1, OrderedAt = DateTime.Today, CreatedAt = DateTime.Now, };
      order.OrderDetails.Add(new OrderDetail() { ProductId = 23, Quantity = 2, Price = 1.99m, CreatedAt = DateTime.Now, });
      order.OrderDetails.Add(new OrderDetail() { ProductId = 532, Quantity = 1, Price = 12.99m, CreatedAt = DateTime.Now, });
      order.OrderDetails.Add(new OrderDetail() { ProductId = 67, Quantity = 4, Price = 5.99m, CreatedAt = DateTime.Now, });

      // Use EF ObjectContext to save the entities one at a time
      using (var ctx = new MyDBEntities())
      {
        ctx.Orders.AddObject(order);
        ctx.SaveChanges();
      }
    }

    private void btnEFUsingTVPs_Click(object sender, EventArgs e)
    {
      // Create an Order entity with child OrderDetail entities
      var order = new Order() { CustomerId = 1, OrderedAt = DateTime.Today, CreatedAt = DateTime.Now, };
      order.OrderDetails.Add(new OrderDetail() { ProductId = 23, Quantity = 2, Price = 1.99m, CreatedAt = DateTime.Now, });
      order.OrderDetails.Add(new OrderDetail() { ProductId = 532, Quantity = 1, Price = 12.99m, CreatedAt = DateTime.Now, });
      order.OrderDetails.Add(new OrderDetail() { ProductId = 67, Quantity = 4, Price = 5.99m, CreatedAt = DateTime.Now, });

      // Use TVPs save the entities all at once
      var orderTvp = new OrderTvp(order);
      var orderDetailsTvp = new OrderDetailTvp(order.OrderDetails);

      using (var conn = new SqlConnection("Data Source=.;Initial Catalog=MyDb;Integrated Security=True;"))
      {
        conn.Open();

        using (var cmd = new SqlCommand("uspInsertOrder", conn))
        {
          cmd.CommandType = CommandType.StoredProcedure;

          var headerParam = cmd.Parameters.AddWithValue("@OrderHeader", orderTvp);
          var detailsParam = cmd.Parameters.AddWithValue("@OrderDetails", orderDetailsTvp);

          headerParam.SqlDbType = SqlDbType.Structured;
          detailsParam.SqlDbType = SqlDbType.Structured;

          // Execute the stored proc
          using (var rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection))
          {
            // Refresh header entity
            rdr.Read();
            order.OrderId = rdr.GetInt32(0);
            order.CreatedAt = rdr.GetDateTime(1);

            // Refresh detail entities
            rdr.NextResult();
            for (var i = 0; i < order.OrderDetails.Count; i++)
            {
              rdr.Read();
              orderDetailsTvp[i].OrderDetailId = rdr.GetInt32(0);
              orderDetailsTvp[i].CreatedAt = rdr.GetDateTime(1);
            }
            rdr.Close();
          }
        }

      }
    }

  }
}
