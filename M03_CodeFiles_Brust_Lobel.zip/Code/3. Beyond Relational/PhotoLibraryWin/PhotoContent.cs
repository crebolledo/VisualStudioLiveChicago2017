﻿namespace PhotoLibraryWin
{
	public class PhotoContent
	{
		public byte[] Photo { get; set; }
		public string Description { get; set; }
	}
}
