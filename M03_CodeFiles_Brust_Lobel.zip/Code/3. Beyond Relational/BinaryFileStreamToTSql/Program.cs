﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BinaryFileStreamToTSql
{
    class Program
    {
        static void Main(string[] args)
        {
            string sql = GetBinaryFileStreamAsTSql(@"..\..\..\Images\Document.jpg");

            Console.WriteLine(sql);
            Console.ReadKey();
        }

        static string GetBinaryFileStreamAsTSql(string inputFile)
        {
            byte[] bytes = null;
            int len = 0;

            using (FileStream fs = new FileStream(inputFile, FileMode.Open))
            {
                len = Convert.ToInt32(fs.Length);
                bytes = new byte[len];
                fs.Read(bytes, 0, len);
                fs.Close();
            }

            string sql = "0x";
            for (int i = 0; i < len; i++)
            {
                string hexChar = string.Format("{0:X}", bytes[i]);
                if (hexChar.Length == 1)
                {
                    hexChar = "0" + hexChar;
                }
                sql += hexChar;
            }

            return sql;
        }
    }
}
