﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MvcClient.Models;

namespace MvcClient.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [Authorize]
        public IActionResult Secure()
        {
            return View();
        }

        [Authorize]
        public async Task<IActionResult> CallApi()
        {
            var token = await HttpContext.GetTokenAsync("access_token");

            var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await client.GetAsync("http://localhost:57779/test");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                ViewData["result"] = json;
            }
            else
            {
                ViewData["result"] = response.StatusCode;
            }

            return View();
        }

        [Authorize]
        public async Task<IActionResult> Refresh()
        {
            var token = await HttpContext.GetTokenAsync("refresh_token");

            var discoClient = new DiscoveryClient("http://localhost:5000");
            var discoResult = await discoClient.GetAsync();

            if (discoResult.IsError)
            {
                throw new Exception(discoResult.Error);
            }

            var tokenClient = new TokenClient(discoResult.TokenEndpoint, "mvc", "secret");
            var tokenResult = await tokenClient.RequestRefreshTokenAsync(token);
            if (tokenResult.IsError)
            {
                throw new Exception(tokenResult.Error);
            }

            var result = await HttpContext.AuthenticateAsync();
            result.Properties.UpdateTokenValue("access_token", tokenResult.AccessToken);
            result.Properties.UpdateTokenValue("refresh_token", tokenResult.RefreshToken);
            await HttpContext.SignInAsync("Cookies", result.Principal, result.Properties);

            return RedirectToAction("Secure");
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
