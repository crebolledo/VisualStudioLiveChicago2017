﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MvcClient.Models;

namespace MvcClient.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult AccessDenied() => View();

        public IActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
            {
                return Forbid();
            }

            return Challenge(new AuthenticationProperties
            {
                RedirectUri = "/Home/Secure"
            }, "oidc");
        }

        public IActionResult Logout() => SignOut(new AuthenticationProperties { RedirectUri = "/" }, "oidc", "Cookies");
    }
}
