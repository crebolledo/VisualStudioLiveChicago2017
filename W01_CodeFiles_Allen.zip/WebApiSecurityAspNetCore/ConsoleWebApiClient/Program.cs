﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using IdentityModel.Client;

namespace ConsoleWebApiClient
{
    class Program
    {
        static void Main(string[] args) => MainAsync().GetAwaiter().GetResult();

        static async Task MainAsync()
        {
            var discoClient = new DiscoveryClient("http://localhost:5000");
            var discoResult = await discoClient.GetAsync();

            if (discoResult.IsError)
            {
                Console.WriteLine($"Disco error: {discoResult.Error}");
                return;
            }

            Console.WriteLine($"Token endpoint: {discoResult.TokenEndpoint}");
            Console.WriteLine();

            var tokenClient = new TokenClient(discoResult.TokenEndpoint, "console", "secret");
            var tokenResult = await tokenClient.RequestClientCredentialsAsync("api1");
            if (tokenResult.IsError)
            {
                Console.WriteLine($"Token error: {tokenResult.Error}");
            }

            Console.WriteLine($"Access Token: {tokenResult.AccessToken}");
            Console.WriteLine();

            var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", tokenResult.AccessToken);

            var response = await client.GetAsync("http://localhost:57779/test");
            Console.WriteLine($"API Result: {(int)response.StatusCode}");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                Console.WriteLine(json);
            }
            Console.WriteLine();

        }
    }
}
