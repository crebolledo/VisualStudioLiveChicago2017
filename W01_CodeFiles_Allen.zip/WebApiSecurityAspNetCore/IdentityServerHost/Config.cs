﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IdentityServer4.Models;

namespace IdentityServerHost
{
    public class Config
    {
        public static IEnumerable<Client> Clients = new List<Client>
        {
            new Client
            {
                ClientId = "console",
                AccessTokenType = AccessTokenType.Reference,
                AllowedGrantTypes = GrantTypes.ClientCredentials,
                ClientSecrets = { new Secret("secret".Sha256()) },
                AllowedScopes = { "api1" }
            },
            new Client
            {
                ClientId = "mvc",
                AllowedGrantTypes = GrantTypes.Hybrid,
                ClientSecrets = { new Secret("secret".Sha256()) },
                RedirectUris = { "http://localhost:57769/signin-oidc" },
                PostLogoutRedirectUris = { "http://localhost:57769/signout-callback-oidc" },
                AllowedScopes = { "openid", "profile", "api1" },
                AllowOfflineAccess = true
            }
        };

        public static IEnumerable<IdentityResource> IdentityResources = new List<IdentityResource>
        {
            new IdentityResources.OpenId(),
            new IdentityResources.Profile(),
            new IdentityResources.Email(),
        };

        public static IEnumerable<ApiResource> Apis = new List<ApiResource>
        {
            new ApiResource("api1", "My API 1")
            {
                ApiSecrets = { new Secret("secret".Sha256()) },
            }
        };
    }
}
