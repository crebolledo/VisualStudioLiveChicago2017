﻿using System;
namespace VSLiveToDo.Models
{
    public class PushToSync
    {
        public string Table { get; set; }
        public string Id { get; set; }
    }
}
